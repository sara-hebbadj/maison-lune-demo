import Link from "next/link";
import { ArrowRight, Award, CalendarCheck2, Check, HeartHandshake, MapPin, PackageCheck, ShieldCheck, Sparkles, Star, UsersRound } from "lucide-react";
import { ButtonLink, Container, DemoPill, SectionHeading } from "@/components/ui";
import { serviceCategoryPreviews, services } from "@/lib/data";
import { ServiceCard } from "@/components/service-card";

const trust = [
  { icon: Star, value: "4.9", label: "Illustrative rating" },
  { icon: CalendarCheck2, value: "500+", label: "Illustrative appointments" },
  { icon: Award, value: "Certified", label: "Beauty professionals" },
  { icon: MapPin, value: "Dubai", label: "Jumeirah studio concept" },
];

const reasons = [
  { icon: UsersRound, title: "Experienced specialists", text: "Thoughtful consultations and focused expertise across hair, nails, brows, lashes, and skin." },
  { icon: PackageCheck, title: "Premium products", text: "Professional formulas and tools selected for comfort, performance, and polished results." },
  { icon: CalendarCheck2, title: "Easy online booking", text: "Choose your treatment, specialist, date, and time without unnecessary back-and-forth." },
  { icon: HeartHandshake, title: "Personalised consultations", text: "Every service begins with attention to your preferences, routine, and desired outcome." },
];

const testimonials = [
  { quote: "The booking felt effortless, and every detail—from the consultation to the finish—felt considered rather than rushed.", name: "Maya A.", service: "Signature Blow-Dry" },
  { quote: "Quiet, polished, and warm. I loved that I could ask questions online before choosing the right facial.", name: "Rania K.", service: "Hydration Facial" },
  { quote: "The brow result was refined and natural. The appointment reminders also made the whole experience feel organised.", name: "Leila N.", service: "Brow Lamination" },
];

export default function HomePage() {
  const featured = services.filter((service) => service.featured).slice(0, 3);
  return (
    <>
      <section className="overflow-hidden border-b border-[#e4dad3] bg-[#f7f1eb]">
        <Container className="grid min-h-[720px] items-center gap-12 py-14 lg:grid-cols-[0.9fr_1.1fr] lg:py-20">
          <div className="relative z-10">
            <DemoPill>Sliubar concept demo · Fictional salon</DemoPill>
            <h1 className="mt-7 max-w-3xl font-serif text-5xl leading-[0.98] tracking-[-0.045em] text-[#2f241f] sm:text-6xl lg:text-7xl">Beauty rituals, thoughtfully designed around you.</h1>
            <p className="mt-7 max-w-xl text-lg leading-8 text-[#6e6059]">Hair, nails, brows, lashes, and skin treatments in a calm Dubai studio designed for effortless self-care.</p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row"><ButtonLink href="/booking" className="sm:min-w-44">Book appointment <ArrowRight className="ml-2" size={17} /></ButtonLink><ButtonLink href="/services" variant="secondary" className="sm:min-w-44">Explore services</ButtonLink></div>
            <div className="mt-10 flex flex-wrap gap-x-6 gap-y-3 text-sm text-[#665851]"><span className="flex items-center gap-2"><Check size={16} className="text-[#9a6f63]" />No account required</span><span className="flex items-center gap-2"><Check size={16} className="text-[#9a6f63]" />Instant demo confirmation</span><span className="flex items-center gap-2"><Check size={16} className="text-[#9a6f63]" />Browser-only data</span></div>
          </div>
          <div className="relative min-h-[520px] lg:min-h-[620px]">
            <div role="img" aria-label="Elegant neutral-toned beauty studio interior" className="absolute inset-0 overflow-hidden rounded-[36px] border border-white/80 bg-[#d8cbc2] bg-cover bg-center shadow-[0_30px_90px_rgba(60,42,36,0.18)]" style={{ backgroundImage: "linear-gradient(180deg, rgba(47,36,31,0.02), rgba(47,36,31,0.28)), url(https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=1600&q=86)" }} />
            <div className="absolute -bottom-4 left-4 right-4 rounded-[24px] border border-white/70 bg-[#fffdfb]/92 p-5 shadow-xl backdrop-blur-md sm:left-auto sm:right-6 sm:w-72"><div className="flex items-center gap-3"><span className="grid size-11 place-items-center rounded-full bg-[#eee2dc] text-[#76594f]"><Sparkles size={19} /></span><div><p className="font-semibold text-[#3c2a24]">Your beauty concierge</p><p className="text-xs text-[#7d6e66]">Ask Luna before you book</p></div></div><p className="mt-4 text-sm leading-6 text-[#64564f]">“How long does brow lamination take?”</p><p className="mt-3 rounded-xl bg-[#f3ebe6] px-3 py-2 text-xs leading-5 text-[#5f5049]">60 minutes · AED 280</p></div>
          </div>
        </Container>
      </section>

      <section className="bg-[#fffdfb] py-8">
        <Container><p className="mb-5 text-center text-[11px] font-semibold uppercase tracking-[0.2em] text-[#8e7c73]">Illustrative proof points for demonstration</p><div className="grid grid-cols-2 gap-px overflow-hidden rounded-[24px] border border-[#e2d8d1] bg-[#e2d8d1] lg:grid-cols-4">{trust.map(({ icon: Icon, value, label }) => <div key={label} className="bg-[#fffdfb] p-6 text-center"><Icon className="mx-auto text-[#9a6f63]" size={20} /><p className="mt-3 font-serif text-3xl text-[#2f241f]">{value}</p><p className="mt-1 text-xs text-[#7c6f68]">{label}</p></div>)}</div></Container>
      </section>

      <section className="py-24 sm:py-28">
        <Container>
          <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end"><SectionHeading eyebrow="Explore the studio" title="One calm destination for your beauty routine." description="A considered menu for everyday maintenance, special occasions, and the appointments in between." /><ButtonLink href="/services" variant="secondary">View full menu <ArrowRight className="ml-2" size={16} /></ButtonLink></div>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{serviceCategoryPreviews.map((item) => <article key={item.category} className="group overflow-hidden rounded-[28px] border border-[#ddd1c8] bg-white"><div aria-hidden="true" className="h-48 bg-[#d8cbc2] bg-cover bg-center transition duration-700 group-hover:scale-[1.02]" style={{ backgroundImage: `linear-gradient(180deg, transparent, rgba(47,36,31,.2)), url(${item.image})` }} /><div className="p-6"><div className="flex items-start justify-between gap-4"><h3 className="font-serif text-3xl text-[#2f241f]">{item.category}</h3><Link href="/services" aria-label={`View ${item.category} services`} className="grid size-10 place-items-center rounded-full border border-[#d8ccc4] text-[#3c2a24] transition group-hover:bg-[#3c2a24] group-hover:text-white"><ArrowRight size={16} /></Link></div><p className="mt-3 text-sm leading-6 text-[#74675f]">{item.description}</p><div className="mt-5 flex items-center justify-between border-t border-[#eee5df] pt-4 text-xs text-[#82736b]"><span>From AED {item.startingPrice}</span><span>{item.duration}</span></div></div></article>)}</div>
        </Container>
      </section>

      <section className="border-y border-[#ded3cc] bg-[#efe5df] py-24 sm:py-28">
        <Container><SectionHeading eyebrow="Why Maison Lune" title="Premium care without the friction." description="The concept combines an elevated salon experience with the practical systems customers now expect." align="center" /><div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4">{reasons.map(({ icon: Icon, title, text }) => <article key={title} className="rounded-[26px] border border-white/70 bg-[#fffaf6]/75 p-6"><span className="grid size-12 place-items-center rounded-2xl bg-[#3c2a24] text-white"><Icon size={20} /></span><h3 className="mt-6 font-serif text-2xl text-[#2f241f]">{title}</h3><p className="mt-3 text-sm leading-6 text-[#6f625c]">{text}</p></article>)}</div></Container>
      </section>

      <section className="py-24 sm:py-28">
        <Container><SectionHeading eyebrow="Featured treatments" title="Designed for the appointments clients book again." description="Three high-intent services presented with clear pricing, duration, and a direct route to booking." /><div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">{featured.map((service) => <ServiceCard key={service.id} service={service} />)}</div></Container>
      </section>

      <section className="bg-[#2f241f] py-24 text-white sm:py-28">
        <Container className="grid gap-12 lg:grid-cols-2 lg:items-center">
          <div><p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#d8b7ac]">AI customer assistant</p><h2 className="mt-5 font-serif text-4xl leading-tight tracking-[-0.035em] sm:text-5xl">Questions answered before they become abandoned bookings.</h2><p className="mt-6 max-w-xl text-base leading-7 text-[#d5c8c0]">Luna answers from a controlled local knowledge base—prices, services, opening hours, preparation instructions, location, and the booking journey—without pretending to know real-time availability.</p><div className="mt-7 grid gap-3 sm:grid-cols-2">{["Prices and durations", "Opening hours", "Preparation guidance", "Human handoff"].map((item) => <p key={item} className="flex items-center gap-2 text-sm text-[#eee5df]"><ShieldCheck size={17} className="text-[#d8b7ac]" />{item}</p>)}</div><p className="mt-7 text-sm text-[#bfb0a7]">Try the “Ask Luna” widget in the corner of this page.</p></div>
          <div className="rounded-[30px] border border-white/10 bg-white/[0.06] p-5 shadow-2xl"><div className="flex items-center gap-3 border-b border-white/10 pb-4"><span className="grid size-11 place-items-center rounded-full bg-[#d8b7ac] text-[#3c2a24]"><Sparkles size={19} /></span><div><p className="font-semibold">Luna, the Maison Lune Assistant</p><p className="text-xs text-white/55">Controlled demo knowledge base</p></div></div><div className="space-y-4 py-6"><div className="ml-auto max-w-[75%] rounded-2xl rounded-tr-sm bg-[#d8b7ac] px-4 py-3 text-sm text-[#3c2a24]">Which facial is best for dry skin?</div><div className="max-w-[88%] rounded-2xl rounded-tl-sm bg-white/10 px-4 py-3 text-sm leading-6 text-[#eee5df]">The Hydration Facial is the closest match in the concept menu. It takes 60 minutes and is AED 420. For sensitivities or clinical concerns, please speak with the team.</div></div><div className="flex flex-wrap gap-2">{["View prices", "Book appointment", "Opening hours"].map((item) => <span key={item} className="rounded-full border border-white/15 px-3 py-2 text-xs text-[#e9ddd6]">{item}</span>)}</div></div>
        </Container>
      </section>

      <section className="py-24 sm:py-28">
        <Container><SectionHeading eyebrow="The booking journey" title="From decision to confirmation in four clear steps." align="center" /><div className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-4">{[
          ["01", "Choose a service", "Browse complete pricing, duration, and treatment descriptions."],
          ["02", "Select a specialist", "Pick a relevant professional or choose no preference."],
          ["03", "Choose a time", "See a simple calendar and realistic demo appointment slots."],
          ["04", "Confirm", "Review every detail, accept the policy, and receive a reference."],
        ].map(([number, title, text], index) => <article key={number} className="relative rounded-[26px] border border-[#ddd1c8] bg-[#fffdfb] p-6"><span className="font-serif text-4xl text-[#c2a69b]">{number}</span><h3 className="mt-7 font-serif text-2xl text-[#2f241f]">{title}</h3><p className="mt-3 text-sm leading-6 text-[#74675f]">{text}</p>{index < 3 ? <ArrowRight className="absolute -right-3 top-1/2 z-10 hidden -translate-y-1/2 rounded-full bg-[#f9f5f0] p-1 text-[#9a6f63] lg:block" size={26} /> : null}</article>)}</div></Container>
      </section>

      <section className="border-y border-[#ded3cc] bg-[#fffdfb] py-24 sm:py-28">
        <Container><SectionHeading eyebrow="Illustrative customer feedback" title="The kind of experience the system is designed to support." description="All testimonials below are fictional and included to demonstrate content hierarchy and social proof presentation." align="center" /><div className="mt-12 grid gap-6 lg:grid-cols-3">{testimonials.map((item) => <figure key={item.name} className="rounded-[28px] border border-[#ddd1c8] bg-[#f9f5f0] p-7"><div className="flex gap-1 text-[#a98556]">{Array.from({ length: 5 }).map((_, index) => <Star key={index} size={16} fill="currentColor" />)}</div><blockquote className="mt-6 font-serif text-2xl leading-9 text-[#3c2a24]">“{item.quote}”</blockquote><figcaption className="mt-6 border-t border-[#e3d9d2] pt-4 text-sm"><span className="font-semibold text-[#4b3d37]">{item.name}</span><span className="ml-2 text-[#8b7b73]">· {item.service}</span></figcaption></figure>)}</div></Container>
      </section>

      <section className="py-24 sm:py-28">
        <Container><div className="overflow-hidden rounded-[36px] bg-[#b98d82] px-6 py-16 text-center text-white shadow-[0_28px_80px_rgba(80,53,44,0.18)] sm:px-12"><p className="text-xs font-semibold uppercase tracking-[0.24em] text-white/75">Ready when you are</p><h2 className="mx-auto mt-5 max-w-3xl font-serif text-4xl leading-tight tracking-[-0.035em] sm:text-6xl">Your next appointment is only a few clicks away.</h2><p className="mx-auto mt-5 max-w-xl text-base leading-7 text-white/80">Complete the full demo journey, then open the dashboard to see your new booking appear automatically.</p><ButtonLink href="/booking" className="mt-8 bg-white text-[#3c2a24] hover:bg-[#fffaf6]">Book appointment <ArrowRight className="ml-2" size={17} /></ButtonLink></div></Container>
      </section>
    </>
  );
}
