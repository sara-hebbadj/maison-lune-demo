import type { Metadata } from "next";
import { Heart, Leaf, ShieldCheck, Sparkles } from "lucide-react";
import { ButtonLink, Container, DemoPill, SectionHeading } from "@/components/ui";
import { specialists } from "@/lib/data";

export const metadata: Metadata = {
  title: "About",
  description: "Discover the fictional story, values, beauty philosophy, team, products, and care standards behind the Maison Lune concept in Dubai.",
};

export default function AboutPage() {
  return (
    <>
      <section className="bg-[#f0e6e0] py-20 sm:py-28"><Container className="grid gap-12 lg:grid-cols-2 lg:items-center"><div><DemoPill>Fictional brand story</DemoPill><h1 className="mt-6 font-serif text-5xl leading-tight tracking-[-0.04em] text-[#2f241f] sm:text-6xl">A beauty studio built around calm, clarity, and considered care.</h1><p className="mt-6 text-lg leading-8 text-[#6e6059]">Maison Lune is a fictional Jumeirah beauty studio imagined for women who want premium expertise without a complicated customer experience.</p><ButtonLink href="/booking" className="mt-8">Experience the demo journey</ButtonLink></div><div role="img" aria-label="Fictional Maison Lune beauty studio interior" className="min-h-[500px] rounded-[34px] border border-white/70 bg-[#d7c9c0] bg-cover bg-center shadow-[0_30px_90px_rgba(60,42,36,0.17)]" style={{ backgroundImage: "linear-gradient(180deg, rgba(47,36,31,.02), rgba(47,36,31,.2)), url(https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=1400&q=84)" }} /></Container></section>

      <section className="py-24"><Container className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr]"><SectionHeading eyebrow="The concept" title="Designed as a complete service business, not only a beautiful website." /><div className="space-y-6 text-base leading-8 text-[#695b54]"><p>The fictional founder, Leena Al Hariri, imagined Maison Lune after noticing how often premium salon experiences were undermined by unclear prices, slow replies, and fragmented booking processes.</p><p>The studio concept brings discovery, questions, booking, confirmation, and internal follow-up into one coherent system. The result is a brand that feels warm to customers and organised behind the scenes.</p><p>Every detail is illustrative—from the founder and team to the location and appointments—but the operational problems the demo solves are real for service businesses.</p></div></Container></section>

      <section className="border-y border-[#dfd4cd] bg-[#fffdfb] py-24"><Container><SectionHeading eyebrow="Our values" title="Beautiful work, delivered thoughtfully." align="center" /><div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4">{[
        { icon: Heart, title: "Warm professionalism", text: "Friendly, attentive service supported by clear expectations and respectful communication." },
        { icon: Sparkles, title: "Refined results", text: "Modern beauty that complements the client rather than overwhelming her." },
        { icon: Leaf, title: "Calm experience", text: "Spacious appointments, considered rituals, and an environment that feels composed." },
        { icon: ShieldCheck, title: "Trust and care", text: "Transparent information, hygiene standards, consent, and responsible boundaries." },
      ].map(({ icon: Icon, title, text }) => <article key={title} className="rounded-[26px] border border-[#e2d8d1] bg-[#f8f3ef] p-6"><Icon className="text-[#9a6f63]" size={23} /><h3 className="mt-5 font-serif text-2xl text-[#2f241f]">{title}</h3><p className="mt-3 text-sm leading-6 text-[#74675f]">{text}</p></article>)}</div></Container></section>

      <section className="py-24"><Container><SectionHeading eyebrow="Fictional specialists" title="Focused expertise, one shared standard of care." description="The team profiles demonstrate how a salon can make expertise visible before the customer reaches the booking form." /><div className="mt-12 grid gap-6 md:grid-cols-2 xl:grid-cols-4">{specialists.map((person) => <article key={person.id} className="rounded-[28px] border border-[#ddd1c8] bg-white p-6"><div className="grid aspect-[4/3] place-items-center rounded-[22px] bg-[#e8ddd6] font-serif text-5xl text-[#76594f]" aria-label={`Photo placeholder for ${person.name}`}>{person.initials}</div><h3 className="mt-6 font-serif text-2xl text-[#2f241f]">{person.name}</h3><p className="mt-1 text-sm font-semibold text-[#9a6f63]">{person.role}</p><p className="mt-4 text-sm leading-6 text-[#74675f]">{person.bio}</p></article>)}</div></Container></section>

      <section className="bg-[#2f241f] py-24 text-white"><Container className="grid gap-10 lg:grid-cols-2"><div><p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#d8b7ac]">Products and standards</p><h2 className="mt-5 font-serif text-4xl leading-tight tracking-[-0.035em] text-white sm:text-5xl">Premium formulas. Responsible care.</h2><p className="mt-5 max-w-xl text-base leading-7 text-[#d0c3bb]">The concept communicates both product quality and the practical standards that support customer trust.</p></div><div className="grid gap-5 sm:grid-cols-2">{[
        ["Professional products", "Premium, salon-grade products selected around service performance and client comfort."],
        ["Single-use care", "Disposable items and protective materials are used where appropriate."],
        ["Tool hygiene", "Illustrative sanitation workflows between every appointment and treatment area."],
        ["Clear boundaries", "Beauty guidance only; medical questions are directed to qualified professionals."],
      ].map(([title, text]) => <div key={title} className="rounded-2xl border border-white/10 bg-white/5 p-5"><h3 className="font-semibold">{title}</h3><p className="mt-2 text-sm leading-6 text-[#cfc1b8]">{text}</p></div>)}</div></Container></section>
    </>
  );
}
