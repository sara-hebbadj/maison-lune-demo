import type { Metadata } from "next";
import "./globals.css";
import { SiteShell } from "@/components/site-shell";

export const metadata: Metadata = {
  metadataBase: new URL("https://maison-lune-demo.vercel.app"),
  title: { default: "Maison Lune Beauty Studio | Sliubar Concept Demo", template: "%s | Maison Lune" },
  description: "A fictional premium Dubai salon concept demonstrating service discovery, AI assistance, online booking, confirmations, and a business dashboard.",
  openGraph: {
    title: "Maison Lune Beauty Studio — Sliubar Concept Demo",
    description: "A complete fictional Dubai salon customer journey and management dashboard created by Sliubar.",
    type: "website",
    locale: "en_AE",
    siteName: "Maison Lune Beauty Studio",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><SiteShell>{children}</SiteShell></body></html>;
}
