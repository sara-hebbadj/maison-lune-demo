import type { Metadata } from "next";
import { Dashboard } from "@/components/dashboard";

export const metadata: Metadata = {
  title: "Salon Dashboard Demo",
  description: "A fictional salon management dashboard demonstrating appointments, enquiries, revenue, follow-ups, schedules, and browser-persisted bookings.",
  robots: { index: false, follow: false },
};

export default function DashboardPage() {
  return <Dashboard />;
}
