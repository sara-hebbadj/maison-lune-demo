import type { Metadata } from "next";
import { Clock3, Mail, MapPin, MessageCircle, Navigation, ParkingCircle, Phone } from "lucide-react";
import { ContactForm } from "@/components/contact-form";
import { ButtonLink, Container, DemoPill, SectionHeading } from "@/components/ui";

export const metadata: Metadata = {
  title: "Contact and Location",
  description: "Contact the fictional Maison Lune Beauty Studio concept in Jumeirah, Dubai and explore its opening hours, parking notes, and enquiry journey.",
};

export default function ContactPage() {
  return (
    <>
      <section className="border-b border-[#ded3cc] bg-[#efe5df] py-20 sm:py-24"><Container><DemoPill>Fictional Jumeirah location</DemoPill><div className="mt-6 grid gap-8 lg:grid-cols-[1fr_0.8fr] lg:items-end"><SectionHeading title="Visit, call, message, or start with Luna." description="The contact experience gives customers several clear ways to reach the team while keeping expectations and location details easy to find." /><ButtonLink href="https://wa.me/?text=Hello%20Maison%20Lune%20demo%20team" className="lg:justify-self-end">WhatsApp demo CTA <MessageCircle className="ml-2" size={17} /></ButtonLink></div></Container></section>
      <section className="py-20 sm:py-24"><Container className="grid gap-10 lg:grid-cols-[0.85fr_1.15fr]"><div><SectionHeading eyebrow="Contact details" title="Maison Lune Beauty Studio" description="All contact information below is fictional and included to demonstrate a complete local Dubai service-business page." /><div className="mt-9 space-y-4">{[
        { icon: MapPin, title: "Location", text: "Jumeirah, Dubai, UAE · Fictional concept address" },
        { icon: Clock3, title: "Opening hours", text: "Mon–Thu: 10:00 AM–8:00 PM\nFri–Sun: 10:00 AM–9:00 PM" },
        { icon: Phone, title: "Phone", text: "+971 4 500 0000" },
        { icon: Mail, title: "Email", text: "hello@maisonlune-demo.com" },
        { icon: ParkingCircle, title: "Parking", text: "Illustrative complimentary basement parking for two hours." },
        { icon: Navigation, title: "Nearby landmark", text: "Five minutes from the Jumeirah Beach Road retail district (illustrative)." },
      ].map(({ icon: Icon, title, text }) => <div key={title} className="flex gap-4 rounded-2xl border border-[#e0d6cf] bg-white p-5"><span className="grid size-11 shrink-0 place-items-center rounded-xl bg-[#eee4de] text-[#76594f]"><Icon size={19} /></span><div><h3 className="font-semibold text-[#3c2a24]">{title}</h3><p className="mt-1 whitespace-pre-line text-sm leading-6 text-[#74675f]">{text}</p></div></div>)}</div></div><ContactForm /></Container></section>
      <section className="pb-24"><Container><div className="relative grid min-h-[430px] place-items-center overflow-hidden rounded-[32px] border border-[#d8ccc4] bg-[#dfd3cb] p-8 text-center"><div className="absolute inset-0 opacity-30" style={{ backgroundImage: "linear-gradient(#b9a79c 1px, transparent 1px), linear-gradient(90deg, #b9a79c 1px, transparent 1px)", backgroundSize: "40px 40px" }} /><div className="relative max-w-md rounded-[28px] border border-white/80 bg-[#fffdfb]/92 p-8 shadow-xl backdrop-blur"><MapPin className="mx-auto text-[#9a6f63]" size={32} /><h2 className="mt-4 font-serif text-3xl text-[#2f241f]">Map integration placeholder</h2><p className="mt-3 text-sm leading-6 text-[#74675f]">A production version could use Google Maps or another approved mapping provider. This demo avoids external paid APIs.</p></div></div></Container></section>
    </>
  );
}
