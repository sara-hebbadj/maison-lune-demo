import type { Metadata } from "next";
import { Suspense } from "react";
import { BookingWizard } from "@/components/booking-wizard";
import { Container, DemoPill } from "@/components/ui";

export const metadata: Metadata = {
  title: "Book an Appointment",
  description: "Complete the fictional Maison Lune five-step booking journey for a premium Dubai salon concept.",
};

export default function BookingPage() {
  return (
    <section className="py-12 sm:py-16">
      <Container>
        <div className="mb-10 max-w-3xl"><DemoPill>Interactive demo booking</DemoPill><h1 className="mt-6 font-serif text-5xl leading-tight tracking-[-0.04em] text-[#2f241f] sm:text-6xl">A clear path from service to confirmation.</h1><p className="mt-5 text-base leading-7 text-[#6f625c]">Complete the flow with fictional details. The booking is saved only in this browser and will appear in the demo dashboard.</p></div>
        <Suspense fallback={<div className="rounded-[28px] border border-[#ddd1c8] bg-white p-10 text-sm text-[#74675f]">Loading booking experience…</div>}><BookingWizard /></Suspense>
      </Container>
    </section>
  );
}
