import type { Metadata } from "next";
import { ServicesBrowser } from "@/components/services-browser";
import { ButtonLink, Container, DemoPill, SectionHeading } from "@/components/ui";

export const metadata: Metadata = {
  title: "Services and Pricing",
  description: "Explore the fictional Maison Lune service menu with illustrative Dubai pricing for hair, nails, brows, lashes, facials, and bridal beauty.",
};

export default function ServicesPage() {
  return (
    <>
      <section className="border-b border-[#e0d6cf] bg-[#efe5df] py-20 sm:py-24"><Container><DemoPill>Transparent illustrative pricing</DemoPill><div className="mt-6 flex flex-col justify-between gap-7 lg:flex-row lg:items-end"><SectionHeading title="Services designed for easy decisions." description="Clear descriptions, duration, and Dubai-based illustrative pricing help customers understand the appointment before they book." /><ButtonLink href="/booking">Start a booking</ButtonLink></div><p className="mt-7 max-w-3xl rounded-2xl border border-[#d8c7bd] bg-white/60 p-4 text-xs leading-6 text-[#74675f]">All services, prices, durations, and treatment descriptions are fictional and provided only for the Sliubar concept demonstration. This is not a real salon menu.</p></Container></section>
      <section className="py-20 sm:py-24"><Container><ServicesBrowser /></Container></section>
    </>
  );
}
