"use client";

import Link from "next/link";
import { Bot, ChevronRight, MessageCircle, Send, Sparkles, UserRound, X } from "lucide-react";
import { FormEvent, useRef, useState } from "react";
import { services } from "@/lib/data";

type Message = { role: "assistant" | "user"; text: string };

const fallback = "I’m not certain about that, but the Maison Lune team can help you directly.";

function answerQuestion(input: string) {
  const q = input.toLowerCase();
  if (/open|hours|close/.test(q)) return "Maison Lune’s illustrative opening hours are Monday–Thursday, 10:00 AM–8:00 PM, and Friday–Sunday, 10:00 AM–9:00 PM.";
  if (/gel manicure|manicure.*gel/.test(q)) return "The Gel Manicure is AED 180 and takes approximately 60 minutes.";
  if (/bridal/.test(q)) return "Yes. The concept menu includes a Bridal Makeup Trial for AED 450 and a Bridal Beauty Package starting from AED 1,800. A consultation is recommended before finalising a package.";
  if (/where|location|located|address/.test(q)) return "The fictional concept location is in Jumeirah, Dubai. The contact page includes a map placeholder, parking notes, and nearby landmark details.";
  if (/brow lamination/.test(q)) return "Brow Lamination takes approximately 60 minutes and is priced at AED 280.";
  if (/tomorrow|availability|available|slot/.test(q)) return "I can guide you to the booking page, but I can’t confirm real-time availability. Please choose a service, date, and available demo time slot to complete the booking.";
  if (/dry skin|dehydrated|facial/.test(q)) return "For dry or dehydrated skin, the Hydration Facial is the closest match in the concept menu. It is a non-medical beauty treatment, so please speak with the team about sensitivities or clinical skin concerns.";
  if (/walk.?in/.test(q)) return "Walk-ins may be accommodated when space allows, but booking ahead is recommended. This demo does not show real-time walk-in capacity.";
  if (/lash.*before|prepare.*lash|lash appointment/.test(q)) return "Arrive with clean lashes and avoid mascara, eye makeup, and oily products around the eye area before a lash appointment. Contact the team directly about sensitivities or medical concerns.";
  if (/person|human|team|staff|speak|call/.test(q)) return "Of course. Use the human handoff below to contact the Maison Lune demo team by phone, email, or WhatsApp.";
  if (/price|cost|how much/.test(q)) {
    const matched = services.find((service) => q.includes(service.name.toLowerCase()) || q.includes(service.category.toLowerCase()));
    if (matched) return `${matched.name} is ${matched.priceLabel ?? `AED ${matched.price}`} and takes approximately ${matched.duration} minutes.`;
    return "You can view the complete illustrative price list on the Services page. I won’t invent a price that is not in the demo menu.";
  }
  if (/book|appointment/.test(q)) return "You can complete a demo booking through the five-step booking form. A booking is only confirmed after the form is reviewed and submitted.";
  if (/medical|diagnos|rash|infection|allergy/.test(q)) return "I can’t provide medical advice. Please consult a qualified healthcare professional, and contact the salon team before booking if a treatment may be unsuitable.";
  return fallback;
}

const quickReplies = ["View prices", "Book appointment", "Opening hours", "Speak to the team"];

export function AiAssistant() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([{ role: "assistant", text: "Hello, I’m Luna. I can help with the illustrative Maison Lune services, prices, hours, preparation guidance, and booking journey." }]);
  const inputRef = useRef<HTMLInputElement>(null);

  function submitText(text: string) {
    const clean = text.trim();
    if (!clean) return;
    setMessages((current) => [...current, { role: "user", text: clean }, { role: "assistant", text: answerQuestion(clean) }]);
    setInput("");
  }

  function submit(event: FormEvent) { event.preventDefault(); submitText(input); }

  function quickReply(label: string) {
    if (label === "View prices") { submitText("Where can I view prices?"); return; }
    if (label === "Book appointment") { submitText("How do I book an appointment?"); return; }
    if (label === "Opening hours") { submitText("What time do you open?"); return; }
    submitText("Can I speak to a person?");
  }

  return (
    <div className="fixed bottom-5 right-5 z-50 sm:bottom-7 sm:right-7">
      {open ? (
        <section role="dialog" aria-label="Luna, the Maison Lune Assistant" className="mb-4 flex h-[min(620px,calc(100vh-110px))] w-[min(390px,calc(100vw-40px))] flex-col overflow-hidden rounded-[28px] border border-[#d8ccc4] bg-[#fffdfb] shadow-[0_28px_90px_rgba(47,36,31,0.28)]">
          <header className="flex items-center justify-between bg-[#3c2a24] px-5 py-4 text-white">
            <div className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-full bg-white/10"><Sparkles size={19} /></span><div><h2 className="font-semibold">Luna</h2><p className="text-xs text-white/70">Maison Lune Assistant · Demo</p></div></div>
            <button type="button" onClick={() => setOpen(false)} className="grid size-10 place-items-center rounded-full hover:bg-white/10" aria-label="Close assistant"><X size={19} /></button>
          </header>
          <div className="flex-1 space-y-4 overflow-y-auto p-4" aria-live="polite">
            {messages.map((message, index) => <div key={`${message.role}-${index}`} className={`flex gap-2 ${message.role === "user" ? "justify-end" : "justify-start"}`}><span className={`mt-1 grid size-7 shrink-0 place-items-center rounded-full ${message.role === "user" ? "order-2 bg-[#eaded7]" : "bg-[#3c2a24] text-white"}`}>{message.role === "user" ? <UserRound size={14} /> : <Bot size={14} />}</span><p className={`max-w-[82%] rounded-2xl px-4 py-3 text-sm leading-6 ${message.role === "user" ? "rounded-tr-sm bg-[#eaded7] text-[#3c2a24]" : "rounded-tl-sm bg-[#f4ede8] text-[#594b44]"}`}>{message.text}</p></div>)}
          </div>
          <div className="border-t border-[#e7ddd6] bg-[#fffaf6] p-4">
            <div className="mb-3 flex gap-2 overflow-x-auto pb-1">{quickReplies.map((label) => <button key={label} type="button" onClick={() => quickReply(label)} className="shrink-0 rounded-full border border-[#d8ccc4] bg-white px-3 py-2 text-xs font-semibold text-[#5f5049] hover:border-[#9a6f63]">{label}</button>)}</div>
            <form onSubmit={submit} className="flex items-center gap-2"><label htmlFor="luna-message" className="sr-only">Ask Luna a question</label><input id="luna-message" ref={inputRef} value={input} onChange={(event) => setInput(event.target.value)} placeholder="Ask about services or booking…" className="min-h-11 flex-1 rounded-full border border-[#d8ccc4] bg-white px-4 text-sm text-[#3c2a24] outline-none placeholder:text-[#a3948b] focus:border-[#9a6f63] focus:ring-2 focus:ring-[#9a6f63]/20" /><button type="submit" className="grid size-11 place-items-center rounded-full bg-[#3c2a24] text-white" aria-label="Send message"><Send size={17} /></button></form>
            <Link href="/contact" className="mt-3 flex items-center justify-center gap-1 text-xs font-semibold text-[#76594f]">Human handoff: contact the team <ChevronRight size={14} /></Link>
          </div>
        </section>
      ) : null}
      <button type="button" onClick={() => { setOpen((value) => !value); setTimeout(() => inputRef.current?.focus(), 100); }} className="flex min-h-14 items-center gap-3 rounded-full bg-[#3c2a24] px-5 text-sm font-semibold text-white shadow-[0_18px_50px_rgba(47,36,31,0.28)] transition hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-[#9a6f63] focus:ring-offset-2" aria-label="Open Luna AI assistant" aria-expanded={open}><MessageCircle size={20} /><span className="hidden sm:inline">Ask Luna</span></button>
    </div>
  );
}
