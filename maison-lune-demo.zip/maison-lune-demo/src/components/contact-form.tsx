"use client";

import { FormEvent, useState } from "react";
import { CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui";

export function ContactForm() {
  const [sent, setSent] = useState(false);
  function submit(event: FormEvent<HTMLFormElement>) { event.preventDefault(); setSent(true); }
  if (sent) return <div className="rounded-[28px] border border-[#d9cbc2] bg-[#fffaf6] p-8 text-center"><CheckCircle2 className="mx-auto text-[#76594f]" size={36} /><h3 className="mt-4 font-serif text-3xl text-[#2f241f]">Demo enquiry recorded</h3><p className="mt-3 text-sm leading-6 text-[#74675f]">This concept form does not send real data. In a production system, the enquiry could create a lead, trigger an acknowledgement, and appear in the dashboard.</p></div>;
  return (
    <form onSubmit={submit} className="rounded-[30px] border border-[#ddd1c8] bg-white p-6 shadow-[0_18px_60px_rgba(63,47,39,0.08)] sm:p-8">
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Full name" id="name"><input required id="name" name="name" autoComplete="name" className="field" /></Field>
        <Field label="Phone number" id="phone"><input required id="phone" name="phone" autoComplete="tel" className="field" /></Field>
        <Field label="Email address" id="email"><input required type="email" id="email" name="email" autoComplete="email" className="field" /></Field>
        <Field label="Service of interest" id="service"><select required id="service" name="service" className="field"><option value="">Choose a service</option><option>Hair</option><option>Nails</option><option>Brows and lashes</option><option>Facials</option><option>Bridal beauty</option></select></Field>
      </div>
      <Field label="How can the team help?" id="message" className="mt-5"><textarea required id="message" name="message" rows={5} className="field resize-none" /></Field>
      <p className="mt-4 text-xs leading-5 text-[#8a7b73]">Demo only: this form does not transmit or store personal data.</p>
      <Button type="submit" className="mt-6 w-full sm:w-auto">Send demo enquiry</Button>
    </form>
  );
}

function Field({ label, id, children, className = "" }: { label: string; id: string; children: React.ReactNode; className?: string }) {
  return <div className={className}><label htmlFor={id} className="mb-2 block text-sm font-semibold text-[#4b3d37]">{label}</label>{children}</div>;
}
