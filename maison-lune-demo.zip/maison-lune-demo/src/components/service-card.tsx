import { ArrowUpRight, Clock3 } from "lucide-react";
import { ButtonLink } from "@/components/ui";
import type { Service } from "@/lib/types";

export function ServiceCard({ service }: { service: Service }) {
  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-[28px] border border-[#ddd1c8] bg-[#fffdfb] shadow-[0_16px_50px_rgba(63,47,39,0.06)] transition hover:-translate-y-1 hover:shadow-[0_22px_60px_rgba(63,47,39,0.11)]">
      <div role="img" aria-label={`${service.category} treatment visual`} className="relative h-52 overflow-hidden bg-[#d8cbc2] bg-cover bg-center transition duration-700 group-hover:scale-[1.02]" style={{ backgroundImage: `linear-gradient(180deg, rgba(47,36,31,0.03), rgba(47,36,31,0.25)), url(${service.image})` }}>
        <span className="absolute left-4 top-4 rounded-full bg-[#fffaf6]/95 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-[#76594f] backdrop-blur">{service.category}</span>
      </div>
      <div className="flex flex-1 flex-col p-6">
        <h3 className="font-serif text-2xl tracking-[-0.02em] text-[#2f241f]">{service.name}</h3>
        <p className="mt-3 flex-1 text-sm leading-6 text-[#74675f]">{service.description}</p>
        <div className="mt-6 flex items-end justify-between gap-4 border-t border-[#eee5df] pt-5">
          <div><p className="text-sm font-semibold text-[#3c2a24]">{service.priceLabel ?? `AED ${service.price}`}</p><p className="mt-1 flex items-center gap-1.5 text-xs text-[#8b7b73]"><Clock3 size={14} />{service.duration} min</p></div>
          <ButtonLink href={`/booking?service=${service.id}`} variant="ghost" className="min-h-10 px-3 py-2">Book <ArrowUpRight className="ml-1" size={16} /></ButtonLink>
        </div>
      </div>
    </article>
  );
}
