"use client";

import { CalendarPlus, CheckCircle2, Clock3, LayoutDashboard, MapPin, MessageCircle, UserRound } from "lucide-react";
import { useEffect, useState } from "react";
import { ButtonLink } from "@/components/ui";
import { readLastBooking } from "@/lib/booking-storage";
import type { DemoBooking } from "@/lib/types";

function readableDate(value: string) {
  return new Intl.DateTimeFormat("en-AE", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(new Date(`${value}T12:00:00`));
}

export function BookingConfirmation() {
  const [booking, setBooking] = useState<DemoBooking | null>(null);
  useEffect(() => {
    const timer = window.setTimeout(() => setBooking(readLastBooking()), 0);
    return () => window.clearTimeout(timer);
  }, []);

  function downloadCalendar() {
    if (!booking) return;
    const startDate = booking.date.replaceAll("-", "");
    const [timePart, modifier] = booking.time.split(" ");
    const [hourText, minuteText] = timePart.split(":");
    let hour = Number(hourText);
    if (modifier === "PM" && hour !== 12) hour += 12;
    if (modifier === "AM" && hour === 12) hour = 0;
    const start = `${startDate}T${String(hour).padStart(2, "0")}${minuteText}00`;
    const endDate = new Date(`${booking.date}T${String(hour).padStart(2, "0")}:${minuteText}:00`);
    endDate.setMinutes(endDate.getMinutes() + booking.duration);
    const end = `${endDate.getFullYear()}${String(endDate.getMonth() + 1).padStart(2, "0")}${String(endDate.getDate()).padStart(2, "0")}T${String(endDate.getHours()).padStart(2, "0")}${String(endDate.getMinutes()).padStart(2, "0")}00`;
    const content = ["BEGIN:VCALENDAR", "VERSION:2.0", "BEGIN:VEVENT", `UID:${booking.reference}@maisonlune-demo`, `DTSTART:${start}`, `DTEND:${end}`, `SUMMARY:${booking.serviceName} — Maison Lune Demo`, "LOCATION:Jumeirah, Dubai (fictional concept location)", `DESCRIPTION:Fictional concept booking ${booking.reference}. This is not a real salon appointment.`, "END:VEVENT", "END:VCALENDAR"].join("\r\n");
    const blob = new Blob([content], { type: "text/calendar;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${booking.reference}.ics`;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  if (!booking) {
    return <div className="mx-auto max-w-xl rounded-[30px] border border-[#ddd1c8] bg-white p-8 text-center"><h1 className="font-serif text-4xl text-[#2f241f]">No recent demo booking found.</h1><p className="mt-4 text-sm leading-6 text-[#74675f]">Complete the booking journey first, then this page will show the locally saved appointment.</p><ButtonLink href="/booking" className="mt-7">Start booking</ButtonLink></div>;
  }

  const whatsappText = encodeURIComponent(`Maison Lune demo booking ${booking.reference}: ${booking.serviceName}, ${readableDate(booking.date)} at ${booking.time}. This is a fictional concept appointment.`);

  return (
    <div className="mx-auto max-w-3xl overflow-hidden rounded-[34px] border border-[#d8ccc4] bg-white shadow-[0_28px_90px_rgba(63,47,39,.13)]">
      <div className="bg-[#3c2a24] px-6 py-12 text-center text-white sm:px-10"><span className="mx-auto grid size-16 place-items-center rounded-full bg-[#d8b7ac] text-[#3c2a24]"><CheckCircle2 size={34} /></span><p className="mt-6 text-xs font-semibold uppercase tracking-[0.22em] text-[#d8b7ac]">Demo booking confirmed</p><h1 className="mt-4 font-serif text-4xl sm:text-5xl">Your appointment journey is complete.</h1><p className="mx-auto mt-4 max-w-xl text-sm leading-6 text-white/65">This is a fictional confirmation created for the Sliubar portfolio demo. No real salon appointment has been made.</p></div>
      <div className="p-6 sm:p-10">
        <div className="flex flex-col gap-3 rounded-2xl bg-[#f4ece7] p-5 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#9a6f63]">Booking reference</p><p className="mt-2 font-serif text-3xl text-[#2f241f]">{booking.reference}</p></div><span className="rounded-full border border-[#d4c4ba] bg-white px-4 py-2 text-xs font-semibold text-[#665851]">Illustrative data</span></div>
        <div className="mt-7 grid gap-4 sm:grid-cols-2">
          <Detail icon={CheckCircle2} label="Service" value={booking.serviceName} sub={`AED ${booking.price} · ${booking.duration} min`} />
          <Detail icon={UserRound} label="Specialist" value={booking.specialistName} sub={booking.specialistName === "No preference" ? "To be assigned in this demo" : "Selected during booking"} />
          <Detail icon={CalendarPlus} label="Date" value={readableDate(booking.date)} sub={booking.time} />
          <Detail icon={MapPin} label="Location" value="Jumeirah, Dubai" sub="Fictional concept location" />
          <Detail icon={Clock3} label="Preferred contact" value={booking.customer.contactMethod} sub={`${booking.customer.phone} · ${booking.customer.email}`} />
        </div>
        <div className="mt-8 grid gap-3 sm:grid-cols-2"><button type="button" onClick={downloadCalendar} className="inline-flex min-h-12 items-center justify-center rounded-full border border-[#bdaea5] bg-white px-5 text-sm font-semibold text-[#3c2a24] hover:bg-[#fffaf6]"><CalendarPlus className="mr-2" size={17} />Add to calendar</button><a href={`https://wa.me/?text=${whatsappText}`} target="_blank" rel="noreferrer" className="inline-flex min-h-12 items-center justify-center rounded-full bg-[#3c2a24] px-5 text-sm font-semibold text-white hover:bg-[#241915]"><MessageCircle className="mr-2" size={17} />WhatsApp confirmation</a></div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2"><ButtonLink href="/" variant="secondary" className="w-full">Return home</ButtonLink><ButtonLink href="/dashboard" className="w-full">Open dashboard <LayoutDashboard className="ml-2" size={17} /></ButtonLink></div>
        <p className="mt-7 text-center text-xs leading-5 text-[#8a7b73]">The appointment is stored only in this browser’s localStorage. Clearing site data will remove it.</p>
      </div>
    </div>
  );
}

function Detail({ icon: Icon, label, value, sub }: { icon: typeof CheckCircle2; label: string; value: string; sub: string }) {
  return <div className="rounded-2xl border border-[#e4dad3] bg-[#fffdfb] p-5"><div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.14em] text-[#9a6f63]"><Icon size={15} />{label}</div><p className="mt-3 font-semibold text-[#3c2a24]">{value}</p><p className="mt-1 text-sm leading-6 text-[#74675f]">{sub}</p></div>;
}
