import Link from "next/link";
import { Camera, Clock3, Mail, MapPin, Phone } from "lucide-react";
import { Logo } from "@/components/logo";
import { Container } from "@/components/ui";
import { DEMO_DISCLAIMER } from "@/lib/data";

export function SiteFooter() {
  return (
    <footer className="border-t border-[#d8ccc4] bg-[#2f241f] text-[#f7efe8]">
      <Container className="py-16">
        <div className="grid gap-12 lg:grid-cols-[1.35fr_0.7fr_1fr_1fr]">
          <div className="max-w-sm">
            <div className="brightness-[4]"><Logo /></div>
            <p className="mt-6 text-sm leading-7 text-[#d8ccc4]">A calm, modern beauty studio concept bringing hair, nails, brows, lashes, skin, and bridal services into one seamless customer journey.</p>
            <p className="mt-5 rounded-2xl border border-white/10 bg-white/5 p-4 text-xs leading-6 text-[#cdbfb6]">{DEMO_DISCLAIMER}</p>
          </div>
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.18em] text-[#d8b7ac]">Navigate</h3>
            <div className="mt-5 flex flex-col gap-3 text-sm text-[#e8ddd6]">
              <Link href="/services">Services</Link><Link href="/booking">Book online</Link><Link href="/about">Our story</Link><Link href="/contact">Contact</Link><Link href="/dashboard">View demo dashboard</Link>
            </div>
          </div>
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.18em] text-[#d8b7ac]">Visit</h3>
            <div className="mt-5 space-y-4 text-sm text-[#e8ddd6]">
              <p className="flex gap-3"><MapPin className="mt-0.5 shrink-0" size={17} />Jumeirah, Dubai, UAE<br />Fictional concept location</p>
              <p className="flex gap-3"><Clock3 className="mt-0.5 shrink-0" size={17} />Mon–Thu: 10 AM–8 PM<br />Fri–Sun: 10 AM–9 PM</p>
            </div>
          </div>
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.18em] text-[#d8b7ac]">Connect</h3>
            <div className="mt-5 space-y-4 text-sm text-[#e8ddd6]">
              <a href="tel:+97145000000" className="flex items-center gap-3"><Phone size={17} />+971 4 500 0000</a>
              <a href="mailto:hello@maisonlune-demo.com" className="flex items-center gap-3"><Mail size={17} />hello@maisonlune-demo.com</a>
              <a href="https://www.instagram.com/" target="_blank" rel="noreferrer" className="flex items-center gap-3"><Camera size={17} />Instagram</a>
            </div>
          </div>
        </div>
        <div className="mt-12 flex flex-col gap-3 border-t border-white/10 pt-6 text-xs text-[#bbaea6] sm:flex-row sm:items-center sm:justify-between">
          <p>Privacy note: this demo stores test bookings only in your browser.</p>
          <p>Concept and system design by <a href="https://sliubar.com" target="_blank" rel="noreferrer" className="font-semibold text-white underline decoration-[#d8b7ac] underline-offset-4">Sliubar</a>.</p>
        </div>
      </Container>
    </footer>
  );
}
