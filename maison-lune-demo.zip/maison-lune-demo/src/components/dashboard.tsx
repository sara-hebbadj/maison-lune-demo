"use client";

import Link from "next/link";
import { Bell, Bot, CalendarDays, CalendarPlus, CheckCircle2, ChevronRight, CircleDollarSign, Clock3, ExternalLink, LayoutDashboard, Menu, MessageSquareText, MoreHorizontal, Search, Sparkles, TrendingUp, UserRound, X } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Logo } from "@/components/logo";
import { DemoPill } from "@/components/ui";
import { readBookings } from "@/lib/booking-storage";
import { DEMO_DISCLAIMER, enquiries, illustrativeAppointments, revenueByCategory } from "@/lib/data";
import type { DemoBooking } from "@/lib/types";

const statusStyles: Record<string, string> = {
  Confirmed: "bg-[#e5f1e8] text-[#326141]",
  Pending: "bg-[#f6edd6] text-[#795f23]",
  Completed: "bg-[#e8e7f4] text-[#4e4b7d]",
  Cancelled: "bg-[#f5e1e1] text-[#884848]",
};

const scheduleTimes = ["10:00 AM", "11:30 AM", "1:00 PM", "2:30 PM", "4:00 PM", "5:30 PM", "7:00 PM"];

function prettyDate(date: string) {
  return new Intl.DateTimeFormat("en-AE", { day: "numeric", month: "short" }).format(new Date(`${date}T12:00:00`));
}

export function Dashboard() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [savedBookings, setSavedBookings] = useState<DemoBooking[]>([]);

  useEffect(() => {
    const refresh = () => setSavedBookings(readBookings());
    refresh();
    window.addEventListener("storage", refresh);
    window.addEventListener("maison-lune-booking-updated", refresh);
    return () => { window.removeEventListener("storage", refresh); window.removeEventListener("maison-lune-booking-updated", refresh); };
  }, []);

  const allAppointments = useMemo(() => [
    ...savedBookings.map((booking) => ({ id: booking.id, customer: booking.customer.fullName, service: booking.serviceName, specialist: booking.specialistName, date: prettyDate(booking.date), time: booking.time, price: booking.price, status: booking.status, isLocal: true })),
    ...illustrativeAppointments.map((item) => ({ ...item, isLocal: false })),
  ], [savedBookings]);

  const metrics = [
    { label: "Today’s appointments", value: String(illustrativeAppointments.filter((item) => item.date === "Today").length + savedBookings.length), change: `${savedBookings.length} browser booking${savedBookings.length === 1 ? "" : "s"}`, icon: CalendarDays },
    { label: "New enquiries", value: "8", change: "Illustrative weekly total", icon: MessageSquareText },
    { label: "Confirmed bookings", value: String(allAppointments.filter((item) => item.status === "Confirmed").length), change: "Includes local demo data", icon: CheckCircle2 },
    { label: "Estimated revenue", value: `AED ${(23460 + savedBookings.reduce((sum, booking) => sum + booking.price, 0)).toLocaleString()}`, change: "Illustrative month-to-date", icon: CircleDollarSign },
    { label: "Pending follow-ups", value: "5", change: "Illustrative action queue", icon: Clock3 },
  ];

  return (
    <div className="min-h-screen bg-[#f2eee9] text-[#2f241f]">
      <aside className={`fixed inset-y-0 left-0 z-50 w-[274px] border-r border-[#e1d7d0] bg-[#fffdfb] p-5 transition-transform lg:translate-x-0 ${mobileOpen ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="flex items-center justify-between"><Logo /><button type="button" onClick={() => setMobileOpen(false)} className="grid size-10 place-items-center rounded-full border border-[#ddd1c8] lg:hidden" aria-label="Close dashboard menu"><X size={18} /></button></div>
        <div className="mt-8 rounded-2xl border border-[#e1d7d0] bg-[#f8f3ef] p-4"><p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-[#9a6f63]">Internal system demo</p><p className="mt-2 text-sm font-semibold text-[#3c2a24]">Maison Lune · Jumeirah</p><p className="mt-1 text-xs text-[#81726a]">No authentication · local data only</p></div>
        <nav className="mt-7 space-y-1" aria-label="Dashboard navigation">
          {[
            { icon: LayoutDashboard, label: "Overview", active: true },
            { icon: CalendarDays, label: "Appointments" },
            { icon: MessageSquareText, label: "Enquiries" },
            { icon: CalendarDays, label: "Calendar" },
            { icon: TrendingUp, label: "Reports" },
            { icon: Bot, label: "AI conversations" },
          ].map(({ icon: Icon, label, active }) => <a key={label} href={`#${label.toLowerCase().replaceAll(" ", "-")}`} onClick={() => setMobileOpen(false)} className={`flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm font-semibold transition ${active ? "bg-[#3c2a24] text-white" : "text-[#665851] hover:bg-[#f2ebe6]"}`}><Icon size={18} />{label}</a>)}
        </nav>
        <div className="absolute bottom-5 left-5 right-5"><Link href="/" className="flex min-h-11 items-center justify-center gap-2 rounded-full border border-[#d7cac1] bg-white text-sm font-semibold text-[#3c2a24]">View salon website <ExternalLink size={15} /></Link></div>
      </aside>
      {mobileOpen ? <button type="button" className="fixed inset-0 z-40 bg-black/30 lg:hidden" onClick={() => setMobileOpen(false)} aria-label="Close dashboard menu overlay" /> : null}

      <div className="lg:pl-[274px]">
        <header className="sticky top-0 z-30 flex h-[74px] items-center justify-between border-b border-[#e1d7d0] bg-[#f2eee9]/90 px-5 backdrop-blur-xl sm:px-7 lg:px-9">
          <div className="flex items-center gap-3"><button type="button" onClick={() => setMobileOpen(true)} className="grid size-11 place-items-center rounded-full border border-[#d8ccc4] bg-white lg:hidden" aria-label="Open dashboard menu"><Menu size={18} /></button><div><p className="text-xs text-[#8b7b73]">Sunday, 5 July</p><h1 className="font-serif text-2xl text-[#2f241f]">Good afternoon, Maison Lune</h1></div></div>
          <div className="flex items-center gap-2"><button type="button" className="hidden min-h-11 items-center gap-2 rounded-full border border-[#d8ccc4] bg-white px-4 text-sm text-[#74675f] sm:flex"><Search size={16} />Search demo data</button><button type="button" className="relative grid size-11 place-items-center rounded-full border border-[#d8ccc4] bg-white" aria-label="Notifications"><Bell size={17} /><span className="absolute right-2.5 top-2.5 size-2 rounded-full bg-[#b98d82]" /></button><span className="grid size-11 place-items-center rounded-full bg-[#3c2a24] font-serif text-sm text-white">ML</span></div>
        </header>

        <main id="overview" className="px-5 py-7 sm:px-7 lg:px-9 lg:py-9">
          <section className="rounded-[26px] border border-[#d8c9c0] bg-[#efe4de] p-5 sm:flex sm:items-center sm:justify-between sm:gap-6"><div><DemoPill>Illustrative dashboard data</DemoPill><p className="mt-3 max-w-3xl text-sm leading-6 text-[#665851]">{DEMO_DISCLAIMER}</p></div><Link href="/booking" className="mt-4 inline-flex min-h-11 shrink-0 items-center justify-center rounded-full bg-[#3c2a24] px-5 text-sm font-semibold text-white sm:mt-0"><CalendarPlus className="mr-2" size={17} />Create test booking</Link></section>

          <section className="mt-7 grid gap-4 sm:grid-cols-2 xl:grid-cols-5" aria-label="Illustrative business metrics">{metrics.map(({ label, value, change, icon: Icon }) => <article key={label} className="rounded-[22px] border border-[#e1d7d0] bg-[#fffdfb] p-5 shadow-[0_10px_30px_rgba(63,47,39,.04)]"><div className="flex items-center justify-between"><span className="grid size-10 place-items-center rounded-xl bg-[#eee4de] text-[#76594f]"><Icon size={18} /></span><span className="text-[9px] font-semibold uppercase tracking-[0.14em] text-[#a08e84]">Illustrative</span></div><p className="mt-5 font-serif text-3xl tracking-[-0.03em] text-[#2f241f]">{value}</p><p className="mt-2 text-xs font-semibold text-[#5f5049]">{label}</p><p className="mt-1 text-[11px] text-[#918078]">{change}</p></article>)}</section>

          <section id="appointments" className="mt-7 overflow-hidden rounded-[26px] border border-[#e1d7d0] bg-[#fffdfb] shadow-[0_10px_35px_rgba(63,47,39,.04)]">
            <DashboardSectionHeader title="Appointments" description="Seed data plus bookings created in this browser" action="View calendar" />
            {savedBookings.length > 0 ? <div className="mx-5 mb-4 rounded-xl border border-[#cddfce] bg-[#edf6ee] px-4 py-3 text-xs font-semibold text-[#416448] sm:mx-6">{savedBookings.length} booking{savedBookings.length === 1 ? "" : "s"} from the customer-facing form are now visible below.</div> : null}
            <div className="overflow-x-auto"><table className="w-full min-w-[900px] border-collapse text-left"><thead><tr className="border-y border-[#eee5df] bg-[#faf7f4] text-[10px] font-semibold uppercase tracking-[0.13em] text-[#8b7b73]">{["Customer", "Service", "Specialist", "Date", "Time", "Price", "Status", ""].map((header) => <th key={header} className="px-5 py-3.5">{header}</th>)}</tr></thead><tbody>{allAppointments.map((item) => <tr key={item.id} className="border-b border-[#eee5df] text-sm last:border-0"><td className="px-5 py-4"><div className="flex items-center gap-3"><span className="grid size-9 place-items-center rounded-full bg-[#e8ddd6] text-xs font-semibold text-[#76594f]">{item.customer.split(" ").map((part) => part[0]).join("").slice(0, 2)}</span><div><p className="font-semibold text-[#3c2a24]">{item.customer}</p>{item.isLocal ? <p className="mt-0.5 text-[10px] font-semibold uppercase tracking-[0.1em] text-[#9a6f63]">Browser booking</p> : null}</div></div></td><td className="px-5 py-4 text-[#665851]">{item.service}</td><td className="px-5 py-4 text-[#665851]">{item.specialist}</td><td className="px-5 py-4 text-[#665851]">{item.date}</td><td className="px-5 py-4 font-semibold text-[#3c2a24]">{item.time}</td><td className="px-5 py-4 text-[#665851]">AED {item.price}</td><td className="px-5 py-4"><span className={`rounded-full px-3 py-1.5 text-xs font-semibold ${statusStyles[item.status]}`}>{item.status}</span></td><td className="px-5 py-4"><button type="button" className="grid size-9 place-items-center rounded-full hover:bg-[#f2ebe6]" aria-label={`More actions for ${item.customer}`}><MoreHorizontal size={17} /></button></td></tr>)}</tbody></table></div>
          </section>

          <div className="mt-7 grid gap-7 xl:grid-cols-[1.2fr_0.8fr]">
            <section id="enquiries" className="overflow-hidden rounded-[26px] border border-[#e1d7d0] bg-[#fffdfb] shadow-[0_10px_35px_rgba(63,47,39,.04)]"><DashboardSectionHeader title="Recent enquiries" description="Illustrative leads from connected channels" action="Open inbox" /><div className="divide-y divide-[#eee5df]">{enquiries.map((item) => <article key={`${item.name}-${item.date}`} className="p-5 sm:p-6"><div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div className="flex gap-3"><span className="grid size-10 shrink-0 place-items-center rounded-full bg-[#eee4de] text-[#76594f]"><UserRound size={17} /></span><div><h3 className="font-semibold text-[#3c2a24]">{item.name}</h3><p className="mt-1 text-xs text-[#8b7b73]">{item.source} · {item.date}</p></div></div><span className="w-fit rounded-full bg-[#f3ebe6] px-3 py-1 text-xs font-semibold text-[#76594f]">{item.status}</span></div><p className="mt-4 text-xs font-semibold uppercase tracking-[0.12em] text-[#9a6f63]">{item.service}</p><p className="mt-2 text-sm leading-6 text-[#6f625c]">{item.message}</p></article>)}</div></section>

            <section className="rounded-[26px] border border-[#e1d7d0] bg-[#fffdfb] shadow-[0_10px_35px_rgba(63,47,39,.04)]"><DashboardSectionHeader title="Popular services" description="Illustrative booking interest" /><div className="space-y-5 p-5 sm:p-6">{[
              ["Gel Manicure", "26 bookings", 88], ["Signature Blow-Dry", "22 bookings", 75], ["Brow Lamination", "18 bookings", 62], ["Hydration Facial", "16 bookings", 54],
            ].map(([name, count, percent]) => <div key={String(name)}><div className="flex justify-between text-sm"><span className="font-semibold text-[#4b3d37]">{name}</span><span className="text-[#8b7b73]">{count}</span></div><div className="mt-2 h-2 rounded-full bg-[#eee5df]"><div className="h-full rounded-full bg-[#b98d82]" style={{ width: `${percent}%` }} /></div></div>)}</div></section>
          </div>

          <div className="mt-7 grid gap-7 xl:grid-cols-[1.2fr_0.8fr]">
            <section id="reports" className="rounded-[26px] border border-[#e1d7d0] bg-[#fffdfb] shadow-[0_10px_35px_rgba(63,47,39,.04)]"><DashboardSectionHeader title="Revenue by category" description="Illustrative monthly service revenue" action="View report" /><div className="space-y-5 p-5 sm:p-6">{revenueByCategory.map((item) => <div key={item.category} className="grid gap-2 sm:grid-cols-[140px_1fr_100px] sm:items-center"><span className="text-sm font-semibold text-[#4b3d37]">{item.category}</span><div className="h-9 overflow-hidden rounded-xl bg-[#f2ebe6]"><div className="flex h-full items-center rounded-xl bg-[#b98d82] px-3 text-[10px] font-semibold uppercase tracking-[0.12em] text-white" style={{ width: `${item.percent}%` }}>{item.percent}%</div></div><span className="text-right text-sm font-semibold text-[#3c2a24]">AED {item.value.toLocaleString()}</span></div>)}<p className="pt-2 text-xs text-[#93827a]">Illustrative visual only; not connected to payments or accounting.</p></div></section>

            <section id="ai-conversations" className="rounded-[26px] border border-[#e1d7d0] bg-[#3c2a24] text-white shadow-[0_14px_40px_rgba(47,36,31,.16)]"><div className="border-b border-white/10 p-5 sm:p-6"><div className="flex items-center gap-3"><span className="grid size-11 place-items-center rounded-xl bg-white/10 text-[#d8b7ac]"><Bot size={19} /></span><div><h2 className="font-serif text-2xl">AI assistant summary</h2><p className="mt-1 text-xs text-white/55">Illustrative conversation activity</p></div></div></div><div className="grid grid-cols-2 gap-px bg-white/10"><MetricDark label="Conversations" value="34" /><MetricDark label="Booking clicks" value="12" /><MetricDark label="Human handoffs" value="5" /><MetricDark label="Answer coverage" value="91%" /></div><div className="p-5 sm:p-6"><p className="flex items-center gap-2 text-sm font-semibold"><Sparkles size={16} className="text-[#d8b7ac]" />Most asked question</p><p className="mt-3 rounded-xl bg-white/[0.06] p-4 text-sm leading-6 text-[#ddd0c8]">“What are your opening hours, and can I book for tomorrow?”</p></div></section>
          </div>

          <section id="calendar" className="mt-7 overflow-hidden rounded-[26px] border border-[#e1d7d0] bg-[#fffdfb] shadow-[0_10px_35px_rgba(63,47,39,.04)]"><DashboardSectionHeader title="Today’s schedule" description="Illustrative daily appointment calendar" action="Weekly view" /><div className="overflow-x-auto p-5 sm:p-6"><div className="min-w-[760px] space-y-2">{scheduleTimes.map((slot, index) => { const match = allAppointments.find((item) => item.time === slot && item.status !== "Cancelled"); return <div key={slot} className="grid grid-cols-[100px_1fr] items-stretch gap-4"><p className="pt-4 text-xs font-semibold text-[#8b7b73]">{slot}</p><div className="min-h-16 border-t border-[#e7ddd6] pt-2">{match ? <div className={`flex items-center justify-between gap-4 rounded-xl border-l-4 p-3 ${index % 2 === 0 ? "border-l-[#b98d82] bg-[#f4e9e4]" : "border-l-[#a98556] bg-[#f6f0e4]"}`}><div><p className="text-sm font-semibold text-[#3c2a24]">{match.service}</p><p className="mt-1 text-xs text-[#74675f]">{match.customer} · {match.specialist}</p></div><span className={`rounded-full px-3 py-1 text-xs font-semibold ${statusStyles[match.status]}`}>{match.status}</span></div> : <p className="px-3 py-3 text-xs text-[#aea098]">Open demo slot</p>}</div></div>; })}</div></div></section>

          <div className="mt-7 grid gap-7 xl:grid-cols-2">
            <section className="rounded-[26px] border border-[#e1d7d0] bg-[#fffdfb] shadow-[0_10px_35px_rgba(63,47,39,.04)]"><DashboardSectionHeader title="Follow-up queue" description="Illustrative customer actions" /><div className="divide-y divide-[#eee5df]">{[
              ["Mariam Saeed", "Booking confirmation", "Before 12:00 PM"], ["Nadine Khoury", "Appointment reminder", "Today, 5:00 PM"], ["Rania Malik", "Rescheduling request", "Needs reply"], ["Leila Farouk", "Post-treatment follow-up", "Tomorrow"],
            ].map(([name, action, due]) => <div key={name} className="flex items-center gap-4 p-5 sm:p-6"><span className="grid size-10 shrink-0 place-items-center rounded-full bg-[#eee4de] font-serif text-sm text-[#76594f]">{name.split(" ").map((part) => part[0]).join("")}</span><div className="min-w-0 flex-1"><p className="font-semibold text-[#3c2a24]">{name}</p><p className="mt-1 text-sm text-[#74675f]">{action}</p></div><div className="text-right"><p className="text-xs font-semibold text-[#9a6f63]">{due}</p><button type="button" className="mt-2 text-xs font-semibold text-[#665851]">Open <ChevronRight className="inline" size={13} /></button></div></div>)}</div></section>

            <section className="rounded-[26px] border border-[#e1d7d0] bg-[#fffdfb] shadow-[0_10px_35px_rgba(63,47,39,.04)]"><DashboardSectionHeader title="Recent activity" description="Illustrative system events" /><div className="space-y-0 p-5 sm:p-6">{[
              { icon: CalendarPlus, title: "New booking received", text: "Gel Manicure booked through the website", time: "4 min ago" },
              { icon: CheckCircle2, title: "Appointment confirmed", text: "Nadine Khoury · Brow Lamination", time: "18 min ago" },
              { icon: Clock3, title: "Rescheduling requested", text: "Rania Malik asked for an evening slot", time: "42 min ago" },
              { icon: Bot, title: "AI handoff to staff", text: "Luna transferred a bridal package enquiry", time: "1 hr ago" },
            ].map(({ icon: ActivityIcon, title, text, time }, index) => <div key={title} className="relative flex gap-4 pb-6 last:pb-0">{index < 3 ? <span className="absolute left-5 top-10 h-[calc(100%-28px)] w-px bg-[#e1d7d0]" /> : null}<span className="relative z-10 grid size-10 shrink-0 place-items-center rounded-full bg-[#eee4de] text-[#76594f]"><ActivityIcon size={17} /></span><div className="flex-1"><div className="flex items-start justify-between gap-3"><p className="text-sm font-semibold text-[#3c2a24]">{title}</p><span className="shrink-0 text-[11px] text-[#9a8a82]">{time}</span></div><p className="mt-1 text-xs leading-5 text-[#74675f]">{text}</p></div></div>)}</div></section>
          </div>

          <footer className="mt-8 flex flex-col gap-2 border-t border-[#ddd1c8] py-5 text-xs text-[#8b7b73] sm:flex-row sm:items-center sm:justify-between"><p>Maison Lune management dashboard · Fictional concept demo</p><p>Concept and system design by <a href="https://sliubar.com" target="_blank" rel="noreferrer" className="font-semibold text-[#3c2a24] underline underline-offset-4">Sliubar</a></p></footer>
        </main>
      </div>
    </div>
  );
}

function DashboardSectionHeader({ title, description, action }: { title: string; description: string; action?: string }) {
  return <div className="flex items-center justify-between gap-4 p-5 sm:p-6"><div><h2 className="font-serif text-2xl text-[#2f241f]">{title}</h2><p className="mt-1 text-xs text-[#8b7b73]">{description}</p></div>{action ? <button type="button" className="shrink-0 text-xs font-semibold text-[#76594f]">{action} <ChevronRight className="inline" size={14} /></button> : null}</div>;
}

function MetricDark({ label, value }: { label: string; value: string }) {
  return <div className="bg-[#3c2a24] p-5"><p className="font-serif text-3xl">{value}</p><p className="mt-1 text-[11px] text-white/55">{label}</p></div>;
}
