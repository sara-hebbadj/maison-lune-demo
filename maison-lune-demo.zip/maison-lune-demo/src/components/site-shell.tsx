"use client";

import { usePathname } from "next/navigation";
import type { PropsWithChildren } from "react";
import { AiAssistant } from "@/components/ai-assistant";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";

export function SiteShell({ children }: PropsWithChildren) {
  const pathname = usePathname();
  const dashboard = pathname.startsWith("/dashboard");
  if (dashboard) return <>{children}</>;
  return <><SiteHeader /><main>{children}</main><SiteFooter /><AiAssistant /></>;
}
