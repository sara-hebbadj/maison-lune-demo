"use client";

import Link from "next/link";
import { Menu, X } from "lucide-react";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { Logo } from "@/components/logo";
import { ButtonLink } from "@/components/ui";

const links = [
  ["Home", "/"],
  ["Services", "/services"],
  ["About", "/about"],
  ["Contact", "/contact"],
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  return (
    <header className="sticky top-0 z-40 border-b border-[#e5dcd5]/90 bg-[#f9f5f0]/92 backdrop-blur-xl">
      <div className="mx-auto flex h-[76px] max-w-[1240px] items-center justify-between px-5 sm:px-8 lg:px-10">
        <Logo />
        <nav className="hidden items-center gap-7 md:flex" aria-label="Primary navigation">
          {links.map(([label, href]) => (
            <Link key={href} href={href} className={`rounded-sm text-sm font-medium transition hover:text-[#9a6f63] focus:outline-none focus:ring-2 focus:ring-[#9a6f63] ${pathname === href ? "text-[#9a6f63]" : "text-[#4b3d37]"}`}>{label}</Link>
          ))}
          <ButtonLink href="/booking" className="ml-1">Book appointment</ButtonLink>
        </nav>
        <button type="button" className="grid size-11 place-items-center rounded-full border border-[#d8ccc4] bg-white text-[#3c2a24] md:hidden" onClick={() => setOpen((value) => !value)} aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open}>
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>
      {open ? (
        <nav className="border-t border-[#e5dcd5] bg-[#f9f5f0] px-5 pb-6 pt-4 md:hidden" aria-label="Mobile navigation">
          <div className="mx-auto flex max-w-[1240px] flex-col gap-2">
            {links.map(([label, href]) => <Link key={href} href={href} onClick={() => setOpen(false)} className="rounded-xl px-4 py-3 text-base font-medium text-[#3c2a24] hover:bg-white">{label}</Link>)}
            <ButtonLink href="/booking" className="mt-2 w-full" onClick={() => setOpen(false)}>Book appointment</ButtonLink>
          </div>
        </nav>
      ) : null}
    </header>
  );
}
