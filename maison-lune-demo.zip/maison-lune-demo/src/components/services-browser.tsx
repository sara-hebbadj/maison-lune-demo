"use client";

import { useMemo, useState } from "react";
import { ServiceCard } from "@/components/service-card";
import { categories, services } from "@/lib/data";
import type { ServiceCategory } from "@/lib/types";

export function ServicesBrowser() {
  const [category, setCategory] = useState<"All" | ServiceCategory>("All");
  const filtered = useMemo(() => category === "All" ? services : services.filter((service) => service.category === category), [category]);
  return (
    <div>
      <div className="flex gap-2 overflow-x-auto pb-3" role="tablist" aria-label="Filter services by category">
        {categories.map((item) => <button key={item} type="button" role="tab" aria-selected={item === category} onClick={() => setCategory(item)} className={`min-h-11 shrink-0 rounded-full px-5 text-sm font-semibold transition focus:outline-none focus:ring-2 focus:ring-[#9a6f63] ${item === category ? "bg-[#3c2a24] text-white" : "border border-[#d7cac1] bg-white text-[#5f5049] hover:border-[#9a6f63]"}`}>{item}</button>)}
      </div>
      <p className="mt-5 text-sm text-[#7c6f68]" aria-live="polite">Showing {filtered.length} {category === "All" ? "services" : category.toLowerCase() + " services"}.</p>
      <div className="mt-8 grid gap-6 md:grid-cols-2 xl:grid-cols-3">{filtered.map((service) => <ServiceCard key={service.id} service={service} />)}</div>
    </div>
  );
}
