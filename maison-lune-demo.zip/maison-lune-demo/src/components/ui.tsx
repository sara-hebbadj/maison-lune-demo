import Link from "next/link";
import type { ButtonHTMLAttributes, PropsWithChildren } from "react";

export function Container({ children, className = "" }: PropsWithChildren<{ className?: string }>) {
  return <div className={`mx-auto w-full max-w-[1240px] px-5 sm:px-8 lg:px-10 ${className}`}>{children}</div>;
}

export function SectionHeading({ eyebrow, title, description, align = "left" }: { eyebrow?: string; title: string; description?: string; align?: "left" | "center" }) {
  return (
    <div className={align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}>
      {eyebrow ? <p className="mb-4 text-xs font-semibold uppercase tracking-[0.24em] text-[#9a6f63]">{eyebrow}</p> : null}
      <h2 className="font-serif text-4xl leading-tight tracking-[-0.03em] text-[#2f241f] sm:text-5xl">{title}</h2>
      {description ? <p className="mt-5 text-base leading-7 text-[#6f625c] sm:text-lg">{description}</p> : null}
    </div>
  );
}

export function ButtonLink({ href, children, variant = "primary", className = "", onClick }: PropsWithChildren<{ href: string; variant?: "primary" | "secondary" | "ghost"; className?: string; onClick?: () => void }>) {
  const styles = {
    primary: "bg-[#3c2a24] text-white hover:bg-[#241915] shadow-[0_14px_36px_rgba(60,42,36,0.18)]",
    secondary: "border border-[#bdaea5] bg-white/75 text-[#3c2a24] hover:bg-white",
    ghost: "text-[#3c2a24] hover:bg-[#eee4dd]",
  };
  return <Link href={href} onClick={onClick} className={`inline-flex min-h-11 items-center justify-center rounded-full px-5 py-3 text-sm font-semibold transition focus:outline-none focus:ring-2 focus:ring-[#9a6f63] focus:ring-offset-2 ${styles[variant]} ${className}`}>{children}</Link>;
}

export function Button({ children, variant = "primary", className = "", ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" | "ghost" }) {
  const styles = {
    primary: "bg-[#3c2a24] text-white hover:bg-[#241915] shadow-[0_14px_36px_rgba(60,42,36,0.16)]",
    secondary: "border border-[#bdaea5] bg-white text-[#3c2a24] hover:bg-[#fbf8f5]",
    ghost: "text-[#3c2a24] hover:bg-[#eee4dd]",
  };
  return <button className={`inline-flex min-h-11 items-center justify-center rounded-full px-5 py-3 text-sm font-semibold transition focus:outline-none focus:ring-2 focus:ring-[#9a6f63] focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 ${styles[variant]} ${className}`} {...props}>{children}</button>;
}

export function DemoPill({ children }: PropsWithChildren) {
  return <span className="inline-flex items-center rounded-full border border-[#d9cbc2] bg-[#fffaf6] px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-[#76594f]">{children}</span>;
}
