"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { CalendarDays, Check, ChevronLeft, ChevronRight, Clock3, Star, UserRound } from "lucide-react";
import { FormEvent, useMemo, useState } from "react";
import { Button } from "@/components/ui";
import { saveBooking } from "@/lib/booking-storage";
import { categories, services, specialists } from "@/lib/data";
import type { BookingCustomer, DemoBooking, Service, ServiceCategory, Specialist } from "@/lib/types";

const timeSlots = ["10:00 AM", "11:30 AM", "1:00 PM", "2:30 PM", "4:00 PM", "5:30 PM", "7:00 PM"];
const steps = ["Service", "Specialist", "Date & time", "Your details", "Review"];

function formatDate(date: Date) {
  return new Intl.DateTimeFormat("en-AE", { weekday: "short", day: "numeric", month: "short" }).format(date);
}

function isoDate(date: Date) {
  const offset = date.getTimezoneOffset();
  return new Date(date.getTime() - offset * 60_000).toISOString().slice(0, 10);
}

function makeReference() {
  return `ML-${Date.now().toString(36).slice(-6).toUpperCase()}`;
}

export function BookingWizard() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const preselected = services.find((service) => service.id === searchParams.get("service"));
  const [step, setStep] = useState(preselected ? 2 : 1);
  const [category, setCategory] = useState<"All" | ServiceCategory>(preselected?.category ?? "All");
  const [service, setService] = useState<Service | null>(preselected ?? null);
  const [specialist, setSpecialist] = useState<Specialist | null>(null);
  const [noPreference, setNoPreference] = useState(false);
  const dates = useMemo(() => Array.from({ length: 8 }, (_, index) => { const date = new Date(); date.setDate(date.getDate() + index + 1); return date; }), []);
  const [date, setDate] = useState<Date | null>(null);
  const [time, setTime] = useState<string | null>(null);
  const [customer, setCustomer] = useState<BookingCustomer>({ fullName: "", phone: "", email: "", contactMethod: "WhatsApp", notes: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [policy, setPolicy] = useState(false);
  const [saving, setSaving] = useState(false);

  const filteredServices = category === "All" ? services : services.filter((item) => item.category === category);

  function validateDetails() {
    const next: Record<string, string> = {};
    if (customer.fullName.trim().length < 2) next.fullName = "Enter your full name.";
    if (!/^\+?[0-9\s()-]{7,}$/.test(customer.phone.trim())) next.phone = "Enter a valid phone number.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer.email.trim())) next.email = "Enter a valid email address.";
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  function nextStep() {
    if (step === 1 && !service) return;
    if (step === 2 && !specialist && !noPreference) return;
    if (step === 3 && (!date || !time)) return;
    if (step === 4 && !validateDetails()) return;
    setStep((current) => Math.min(5, current + 1));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function previousStep() {
    setStep((current) => Math.max(1, current - 1));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function chooseService(item: Service) {
    setService(item);
    setCategory(item.category);
  }

  function chooseSpecialist(item: Specialist | null) {
    setSpecialist(item);
    setNoPreference(item === null);
  }

  function isUnavailable(dateIndex: number, slotIndex: number) {
    return (dateIndex + slotIndex) % 4 === 0 || (dateIndex === 0 && slotIndex < 2);
  }

  function confirm(event: FormEvent) {
    event.preventDefault();
    if (!service || !date || !time || !policy || saving) return;
    setSaving(true);
    const reference = makeReference();
    const booking: DemoBooking = {
      id: crypto.randomUUID(),
      reference,
      createdAt: new Date().toISOString(),
      serviceId: service.id,
      serviceName: service.name,
      category: service.category,
      specialistId: specialist?.id ?? "no-preference",
      specialistName: specialist?.name ?? "No preference",
      date: isoDate(date),
      time,
      duration: service.duration,
      price: service.price,
      customer,
      status: "Confirmed",
      source: "Website",
    };
    saveBooking(booking);
    router.push("/booking/confirmation");
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_340px] lg:items-start">
      <section className="overflow-hidden rounded-[30px] border border-[#ddd1c8] bg-white shadow-[0_18px_60px_rgba(63,47,39,0.07)]">
        <div className="border-b border-[#e7ddd6] bg-[#fffaf6] px-5 py-5 sm:px-8">
          <ol className="flex items-center justify-between gap-2" aria-label="Booking progress">
            {steps.map((label, index) => {
              const number = index + 1;
              const active = step === number;
              const done = step > number;
              return <li key={label} className="flex min-w-0 flex-1 items-center gap-2"><span className={`grid size-8 shrink-0 place-items-center rounded-full text-xs font-semibold ${done ? "bg-[#9a6f63] text-white" : active ? "bg-[#3c2a24] text-white" : "border border-[#d5c7be] text-[#8b7b73]"}`}>{done ? <Check size={15} /> : number}</span><span className={`hidden truncate text-xs font-semibold sm:block ${active ? "text-[#3c2a24]" : "text-[#8b7b73]"}`}>{label}</span>{index < steps.length - 1 ? <span className="ml-auto h-px w-full max-w-10 bg-[#ddd1c8]" /> : null}</li>;
            })}
          </ol>
        </div>

        <div className="p-5 sm:p-8">
          {step === 1 ? (
            <div>
              <StepHeader number="01" title="Choose a service" description="Select the treatment you want to book. Prices and availability are illustrative." />
              <div className="mt-7 flex gap-2 overflow-x-auto pb-2">{categories.map((item) => <button key={item} type="button" onClick={() => setCategory(item)} className={`min-h-10 shrink-0 rounded-full px-4 text-sm font-semibold ${category === item ? "bg-[#3c2a24] text-white" : "border border-[#d8ccc4] bg-white text-[#665851]"}`}>{item}</button>)}</div>
              <div className="mt-6 grid gap-4 md:grid-cols-2">{filteredServices.map((item) => <button key={item.id} type="button" onClick={() => chooseService(item)} aria-pressed={service?.id === item.id} className={`rounded-[22px] border p-5 text-left transition focus:outline-none focus:ring-2 focus:ring-[#9a6f63] ${service?.id === item.id ? "border-[#9a6f63] bg-[#fff8f4] shadow-[0_12px_30px_rgba(75,53,44,.08)]" : "border-[#e0d6cf] hover:border-[#b69a8e]"}`}><div className="flex items-start justify-between gap-4"><div><p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#9a6f63]">{item.category}</p><h3 className="mt-2 font-serif text-2xl text-[#2f241f]">{item.name}</h3></div>{service?.id === item.id ? <span className="grid size-7 shrink-0 place-items-center rounded-full bg-[#3c2a24] text-white"><Check size={15} /></span> : null}</div><p className="mt-3 text-sm leading-6 text-[#74675f]">{item.description}</p><div className="mt-5 flex items-center justify-between border-t border-[#eee5df] pt-4 text-sm"><span className="font-semibold text-[#3c2a24]">{item.priceLabel ?? `AED ${item.price}`}</span><span className="flex items-center gap-1.5 text-[#82736b]"><Clock3 size={15} />{item.duration} min</span></div></button>)}</div>
            </div>
          ) : null}

          {step === 2 ? (
            <div>
              <StepHeader number="02" title="Choose a specialist" description="Select a team member or choose no preference for the widest demo availability." />
              <div className="mt-7 grid gap-4 md:grid-cols-2">
                <button type="button" onClick={() => chooseSpecialist(null)} aria-pressed={noPreference} className={`rounded-[22px] border p-5 text-left transition focus:outline-none focus:ring-2 focus:ring-[#9a6f63] ${noPreference ? "border-[#9a6f63] bg-[#fff8f4]" : "border-[#e0d6cf]"}`}><div className="flex items-center gap-4"><span className="grid size-14 place-items-center rounded-full bg-[#e8ddd6] text-[#76594f]"><UserRound size={22} /></span><div><h3 className="font-serif text-2xl text-[#2f241f]">No preference</h3><p className="mt-1 text-sm text-[#74675f]">Match me with an available specialist.</p></div></div></button>
                {specialists.map((person) => <button key={person.id} type="button" onClick={() => chooseSpecialist(person)} aria-pressed={specialist?.id === person.id} className={`rounded-[22px] border p-5 text-left transition focus:outline-none focus:ring-2 focus:ring-[#9a6f63] ${specialist?.id === person.id ? "border-[#9a6f63] bg-[#fff8f4]" : "border-[#e0d6cf] hover:border-[#b69a8e]"}`}><div className="flex items-start gap-4"><span className="grid size-14 shrink-0 place-items-center rounded-full bg-[#e8ddd6] font-serif text-lg text-[#76594f]">{person.initials}</span><div className="min-w-0"><div className="flex items-start justify-between gap-2"><div><h3 className="font-serif text-xl text-[#2f241f]">{person.name}</h3><p className="mt-1 text-xs font-semibold text-[#9a6f63]">{person.role}</p></div>{specialist?.id === person.id ? <Check className="text-[#76594f]" size={17} /> : null}</div><p className="mt-3 text-sm leading-6 text-[#74675f]">{person.bio}</p><div className="mt-4 flex flex-wrap items-center gap-3 text-xs"><span className="flex items-center gap-1 text-[#76594f]"><Star size={14} fill="currentColor" />{person.rating}</span><span className="rounded-full bg-[#f0e8e2] px-2.5 py-1 text-[#65564f]">{person.availability}</span></div></div></div></button>)}
              </div>
            </div>
          ) : null}

          {step === 3 ? (
            <div>
              <StepHeader number="03" title="Choose a date and time" description="The slot pattern is generated locally for this demo and is not real-time salon availability." />
              <h3 className="mt-7 text-sm font-semibold text-[#4b3d37]">Select a date</h3>
              <div className="mt-3 flex gap-3 overflow-x-auto pb-3">{dates.map((item) => <button key={item.toISOString()} type="button" onClick={() => { setDate(item); setTime(null); }} aria-pressed={date ? isoDate(date) === isoDate(item) : false} className={`min-h-20 min-w-28 shrink-0 rounded-2xl border px-4 py-3 text-center transition ${date && isoDate(date) === isoDate(item) ? "border-[#3c2a24] bg-[#3c2a24] text-white" : "border-[#d8ccc4] bg-white text-[#5f5049] hover:border-[#9a6f63]"}`}><span className="block text-xs font-semibold uppercase tracking-[0.12em] opacity-70">{item.toLocaleDateString("en-AE", { weekday: "short" })}</span><span className="mt-1 block font-serif text-2xl">{item.getDate()}</span><span className="block text-xs opacity-70">{item.toLocaleDateString("en-AE", { month: "short" })}</span></button>)}</div>
              <h3 className="mt-7 text-sm font-semibold text-[#4b3d37]">Available demo times</h3>
              {!date ? <p className="mt-4 rounded-2xl bg-[#f6efea] p-5 text-sm text-[#74675f]">Choose a date to see appointment times.</p> : <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">{timeSlots.map((slot, slotIndex) => { const dateIndex = dates.findIndex((item) => isoDate(item) === isoDate(date)); const unavailable = isUnavailable(dateIndex, slotIndex); return <button key={slot} type="button" disabled={unavailable} onClick={() => setTime(slot)} aria-pressed={time === slot} className={`min-h-12 rounded-xl border text-sm font-semibold transition ${unavailable ? "cursor-not-allowed border-[#eee5df] bg-[#f4f1ee] text-[#b8aaa1] line-through" : time === slot ? "border-[#3c2a24] bg-[#3c2a24] text-white" : "border-[#d8ccc4] bg-white text-[#5f5049] hover:border-[#9a6f63]"}`}>{slot}</button>; })}</div>}
              <p className="mt-4 text-xs text-[#8a7b73]">Unavailable slots are intentionally included to demonstrate scheduling states.</p>
            </div>
          ) : null}

          {step === 4 ? (
            <div>
              <StepHeader number="04" title="Your details" description="These details remain in your browser and are used only to populate the concept dashboard." />
              <div className="mt-7 grid gap-5 sm:grid-cols-2">
                <Field label="Full name" id="booking-name" error={errors.fullName}><input id="booking-name" value={customer.fullName} onChange={(event) => setCustomer({ ...customer, fullName: event.target.value })} autoComplete="name" aria-invalid={Boolean(errors.fullName)} className="field" /></Field>
                <Field label="Phone number" id="booking-phone" error={errors.phone}><input id="booking-phone" value={customer.phone} onChange={(event) => setCustomer({ ...customer, phone: event.target.value })} autoComplete="tel" placeholder="+971 50 000 0000" aria-invalid={Boolean(errors.phone)} className="field" /></Field>
                <Field label="Email address" id="booking-email" error={errors.email}><input type="email" id="booking-email" value={customer.email} onChange={(event) => setCustomer({ ...customer, email: event.target.value })} autoComplete="email" aria-invalid={Boolean(errors.email)} className="field" /></Field>
                <Field label="Preferred contact method" id="booking-contact"><select id="booking-contact" value={customer.contactMethod} onChange={(event) => setCustomer({ ...customer, contactMethod: event.target.value as BookingCustomer["contactMethod"] })} className="field"><option>WhatsApp</option><option>Phone</option><option>Email</option></select></Field>
              </div>
              <Field label="Optional notes" id="booking-notes" className="mt-5"><textarea id="booking-notes" value={customer.notes} onChange={(event) => setCustomer({ ...customer, notes: event.target.value })} rows={5} className="field resize-none" placeholder="Preferences, accessibility needs, or anything the team should know." /></Field>
              <p className="mt-4 text-xs leading-5 text-[#8a7b73]">Do not enter sensitive medical or financial information. This is a local browser demo.</p>
            </div>
          ) : null}

          {step === 5 ? (
            <form onSubmit={confirm}>
              <StepHeader number="05" title="Review and confirm" description="Check every detail before creating your fictional booking reference." />
              <div className="mt-7 divide-y divide-[#e9e0da] rounded-[24px] border border-[#ddd1c8] bg-[#fffaf6] px-5 sm:px-6">
                <ReviewRow label="Service" value={service?.name ?? "—"} sub={`${service?.duration ?? 0} minutes · ${service?.priceLabel ?? `AED ${service?.price ?? 0}`}`} />
                <ReviewRow label="Specialist" value={specialist?.name ?? "No preference"} sub={specialist?.role ?? "Assigned according to demo availability"} />
                <ReviewRow label="Appointment" value={date ? formatDate(date) : "—"} sub={time ?? "—"} />
                <ReviewRow label="Customer" value={customer.fullName} sub={`${customer.phone} · ${customer.email}`} />
                <ReviewRow label="Contact" value={customer.contactMethod} sub={customer.notes?.trim() ? `Notes: ${customer.notes}` : "No additional notes"} />
              </div>
              <label className="mt-6 flex cursor-pointer items-start gap-3 rounded-2xl border border-[#ddd1c8] bg-white p-4"><input type="checkbox" checked={policy} onChange={(event) => setPolicy(event.target.checked)} className="mt-1 size-4 accent-[#3c2a24]" /><span className="text-sm leading-6 text-[#665851]">I acknowledge the illustrative 24-hour cancellation policy and understand that this is a fictional concept booking, not a real salon appointment.</span></label>
              <Button type="submit" disabled={!policy || saving} className="mt-6 w-full sm:w-auto">{saving ? "Creating booking…" : "Confirm demo booking"}</Button>
            </form>
          ) : null}
        </div>

        {step < 5 ? (
          <div className="flex items-center justify-between border-t border-[#e7ddd6] bg-[#fffaf6] px-5 py-5 sm:px-8">
            <Button type="button" variant="ghost" onClick={previousStep} disabled={step === 1}><ChevronLeft className="mr-1" size={17} />Back</Button>
            <Button type="button" onClick={nextStep} disabled={(step === 1 && !service) || (step === 2 && !specialist && !noPreference) || (step === 3 && (!date || !time))}>Continue <ChevronRight className="ml-1" size={17} /></Button>
          </div>
        ) : null}
      </section>

      <aside className="rounded-[28px] border border-[#d9cdc5] bg-[#3c2a24] p-6 text-white shadow-[0_20px_60px_rgba(47,36,31,.15)] lg:sticky lg:top-28">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#d8b7ac]">Appointment summary</p>
        <h2 className="mt-4 font-serif text-3xl">{service?.name ?? "Choose your treatment"}</h2>
        <div className="mt-6 space-y-4 border-y border-white/10 py-5 text-sm">
          <SummaryItem icon={Clock3} label="Duration" value={service ? `${service.duration} min` : "—"} />
          <SummaryItem icon={UserRound} label="Specialist" value={specialist?.name ?? (noPreference ? "No preference" : "—")} />
          <SummaryItem icon={CalendarDays} label="Date and time" value={date && time ? `${formatDate(date)}, ${time}` : "—"} />
        </div>
        <div className="mt-5 flex items-end justify-between"><span className="text-sm text-white/65">Estimated total</span><span className="font-serif text-3xl">{service ? service.priceLabel ?? `AED ${service.price}` : "AED —"}</span></div>
        <p className="mt-5 text-xs leading-5 text-white/55">No payment is collected. This flow stores the demo booking in localStorage so it can appear inside the dashboard.</p>
      </aside>
    </div>
  );
}

function StepHeader({ number, title, description }: { number: string; title: string; description: string }) {
  return <div><p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#9a6f63]">Step {number}</p><h2 className="mt-3 font-serif text-4xl tracking-[-0.03em] text-[#2f241f]">{title}</h2><p className="mt-3 max-w-2xl text-sm leading-6 text-[#74675f]">{description}</p></div>;
}

function Field({ label, id, error, children, className = "" }: { label: string; id: string; error?: string; children: React.ReactNode; className?: string }) {
  return <div className={className}><label htmlFor={id} className="mb-2 block text-sm font-semibold text-[#4b3d37]">{label}</label>{children}{error ? <p className="mt-2 text-xs font-semibold text-[#a84d4d]">{error}</p> : null}</div>;
}

function ReviewRow({ label, value, sub }: { label: string; value: string; sub: string }) {
  return <div className="grid gap-2 py-5 sm:grid-cols-[140px_1fr]"><p className="text-xs font-semibold uppercase tracking-[0.13em] text-[#9a6f63]">{label}</p><div><p className="font-semibold text-[#3c2a24]">{value}</p><p className="mt-1 text-sm leading-6 text-[#74675f]">{sub}</p></div></div>;
}

function SummaryItem({ icon: Icon, label, value }: { icon: typeof Clock3; label: string; value: string }) {
  return <div className="flex gap-3"><Icon className="mt-0.5 shrink-0 text-[#d8b7ac]" size={17} /><div><p className="text-white/55">{label}</p><p className="mt-1 font-medium text-white">{value}</p></div></div>;
}
