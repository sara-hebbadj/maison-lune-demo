import Link from "next/link";

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" className="group inline-flex items-center gap-3 rounded-sm focus:outline-none focus:ring-2 focus:ring-[#9a6f63]" aria-label="Maison Lune home">
      <span className="grid size-10 place-items-center rounded-full border border-[#9a6f63]/50 bg-[#fffaf6] font-serif text-lg text-[#3c2a24]">ML</span>
      {!compact ? (
        <span>
          <span className="block font-serif text-xl leading-none tracking-[-0.02em] text-[#2f241f]">Maison Lune</span>
          <span className="mt-1 block text-[9px] font-semibold uppercase tracking-[0.24em] text-[#8a7770]">Beauty Studio</span>
        </span>
      ) : null}
    </Link>
  );
}
