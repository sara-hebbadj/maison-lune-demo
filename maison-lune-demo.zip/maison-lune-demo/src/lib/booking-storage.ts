import type { DemoBooking } from "@/lib/types";

export const BOOKINGS_KEY = "maison-lune-demo-bookings";
export const LAST_BOOKING_KEY = "maison-lune-last-booking";

export function readBookings(): DemoBooking[] {
  if (typeof window === "undefined") return [];
  try {
    const value = window.localStorage.getItem(BOOKINGS_KEY);
    return value ? (JSON.parse(value) as DemoBooking[]) : [];
  } catch {
    return [];
  }
}

export function saveBooking(booking: DemoBooking) {
  if (typeof window === "undefined") return;
  const existing = readBookings();
  window.localStorage.setItem(BOOKINGS_KEY, JSON.stringify([booking, ...existing]));
  window.localStorage.setItem(LAST_BOOKING_KEY, JSON.stringify(booking));
  window.dispatchEvent(new Event("maison-lune-booking-updated"));
}

export function readLastBooking(): DemoBooking | null {
  if (typeof window === "undefined") return null;
  try {
    const value = window.localStorage.getItem(LAST_BOOKING_KEY);
    return value ? (JSON.parse(value) as DemoBooking) : null;
  } catch {
    return null;
  }
}
