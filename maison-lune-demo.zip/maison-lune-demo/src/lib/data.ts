import type { Service, ServiceCategory, Specialist } from "@/lib/types";

export const DEMO_DISCLAIMER =
  "Maison Lune Beauty Studio is a fictional concept created by Sliubar to demonstrate website, booking, AI assistant, automation, and dashboard capabilities. All names, data, appointments, reviews, and statistics are illustrative.";

const images: Record<ServiceCategory, string> = {
  Hair: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=1200&q=82",
  Nails: "https://images.unsplash.com/photo-1604654894610-df63bc536371?auto=format&fit=crop&w=1200&q=82",
  Brows: "https://images.unsplash.com/photo-1562322140-8baeececf3df?auto=format&fit=crop&w=1200&q=82",
  Lashes: "https://images.unsplash.com/photo-1519699047748-de8e457a634e?auto=format&fit=crop&w=1200&q=82",
  Facials: "https://images.unsplash.com/photo-1619451334792-150fd785ee74?auto=format&fit=crop&w=1200&q=82",
  Bridal: "https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?auto=format&fit=crop&w=1200&q=82",
};

export const categories: Array<"All" | ServiceCategory> = [
  "All",
  "Hair",
  "Nails",
  "Brows",
  "Lashes",
  "Facials",
  "Bridal",
];

export const services: Service[] = [
  { id: "signature-blow-dry", name: "Signature Blow-Dry", category: "Hair", description: "A polished, long-lasting finish tailored to your hair texture and preferred movement.", duration: 45, price: 180, image: images.Hair, featured: true },
  { id: "haircut-finish", name: "Haircut and Finish", category: "Hair", description: "Consultation-led shaping, precision cutting, and a refined salon finish.", duration: 60, price: 320, image: images.Hair },
  { id: "root-colour", name: "Root Colour", category: "Hair", description: "Seamless root coverage with a customised tone and professional finish.", duration: 90, price: 420, image: images.Hair },
  { id: "full-hair-colour", name: "Full Hair Colour", category: "Hair", description: "A complete colour refresh using premium formulas selected for your desired result.", duration: 120, price: 650, image: images.Hair },
  { id: "hair-treatment", name: "Hair Treatment", category: "Hair", description: "A restorative ritual for softness, shine, hydration, and improved manageability.", duration: 45, price: 250, image: images.Hair },

  { id: "classic-manicure", name: "Classic Manicure", category: "Nails", description: "Nail shaping, cuticle care, massage, and classic polish application.", duration: 45, price: 120, image: images.Nails },
  { id: "gel-manicure", name: "Gel Manicure", category: "Nails", description: "Detailed nail preparation and glossy, chip-resistant gel colour.", duration: 60, price: 180, image: images.Nails, featured: true },
  { id: "classic-pedicure", name: "Classic Pedicure", category: "Nails", description: "Complete foot and nail care with exfoliation, massage, and polish.", duration: 60, price: 150, image: images.Nails },
  { id: "gel-pedicure", name: "Gel Pedicure", category: "Nails", description: "A meticulous pedicure completed with durable gel colour and high shine.", duration: 75, price: 210, image: images.Nails },
  { id: "nail-art", name: "Nail Art Add-On", category: "Nails", description: "Minimal, elegant detailing customised to complement your chosen manicure.", duration: 20, price: 50, image: images.Nails },

  { id: "brow-shaping", name: "Brow Shaping", category: "Brows", description: "Precise shaping designed around your natural growth and facial proportions.", duration: 30, price: 90, image: images.Brows },
  { id: "brow-tint", name: "Brow Tint", category: "Brows", description: "A customised tint that adds definition while keeping the result soft and natural.", duration: 30, price: 100, image: images.Brows },
  { id: "brow-lamination", name: "Brow Lamination", category: "Brows", description: "A smoothing and setting treatment for fuller-looking, beautifully groomed brows.", duration: 60, price: 280, image: images.Brows, featured: true },

  { id: "lash-lift", name: "Lash Lift", category: "Lashes", description: "A natural-looking curl and lift that opens the eyes without extensions.", duration: 60, price: 300, image: images.Lashes },
  { id: "classic-lash-extensions", name: "Classic Lash Extensions", category: "Lashes", description: "Individually applied extensions for elegant length and understated definition.", duration: 120, price: 420, image: images.Lashes },
  { id: "lash-refill", name: "Lash Refill", category: "Lashes", description: "A maintenance appointment to refresh and rebalance classic lash extensions.", duration: 75, price: 250, image: images.Lashes },

  { id: "express-glow-facial", name: "Express Glow Facial", category: "Facials", description: "A time-efficient cleanse, exfoliation, mask, and hydration boost for renewed radiance.", duration: 45, price: 280, image: images.Facials },
  { id: "hydration-facial", name: "Hydration Facial", category: "Facials", description: "A moisture-focused treatment created to comfort dry, dehydrated, or tired-looking skin.", duration: 60, price: 420, image: images.Facials, featured: true },
  { id: "signature-skin-ritual", name: "Signature Skin Ritual", category: "Facials", description: "A personalised 90-minute facial combining deep cleansing, massage, masks, and targeted care.", duration: 90, price: 580, image: images.Facials },

  { id: "bridal-hair-consultation", name: "Bridal Hair Consultation", category: "Bridal", description: "A focused consultation to define your wedding-day hair direction and preparation plan.", duration: 60, price: 350, image: images.Bridal },
  { id: "bridal-makeup-trial", name: "Bridal Makeup Trial", category: "Bridal", description: "A complete bridal makeup trial refined around your features, outfit, and photography style.", duration: 90, price: 450, image: images.Bridal },
  { id: "bridal-beauty-package", name: "Bridal Beauty Package", category: "Bridal", description: "A tailored package combining consultation, trial, and wedding-day beauty services.", duration: 180, price: 1800, priceLabel: "From AED 1,800", image: images.Bridal },
];

export const specialists: Specialist[] = [
  { id: "lina-rahman", name: "Lina Rahman", role: "Senior Hair Stylist", specialty: "Cuts, colour, polished styling", bio: "Lina is known for wearable colour, considered consultations, and finishes that still feel effortless.", rating: 4.9, availability: "Available today", initials: "LR" },
  { id: "maya-el-khoury", name: "Maya El-Khoury", role: "Nail Artist", specialty: "Gel care and minimal nail art", bio: "Maya combines meticulous prep with modern, understated colour and detail.", rating: 4.9, availability: "Next available tomorrow", initials: "ME" },
  { id: "sofia-haddad", name: "Sofia Haddad", role: "Brow and Lash Specialist", specialty: "Natural definition and symmetry", bio: "Sofia creates softly structured brows and lashes that complement each client’s features.", rating: 4.8, availability: "Limited this week", initials: "SH" },
  { id: "noor-al-mansoori", name: "Noor Al-Mansoori", role: "Skin Therapist", specialty: "Hydration and glow-focused facials", bio: "Noor takes a calm, education-led approach to personalised, non-medical skin treatments.", rating: 4.9, availability: "Available today", initials: "NA" },
];

export const serviceCategoryPreviews = [
  { category: "Hair" as const, description: "Precision cuts, dimensional colour, treatments, and polished styling.", startingPrice: 180, duration: "45–120 min" },
  { category: "Nails" as const, description: "Meticulous manicures, pedicures, gel finishes, and minimal art.", startingPrice: 120, duration: "45–75 min" },
  { category: "Brows" as const, description: "Shape, tint, and lamination designed around your natural features.", startingPrice: 90, duration: "30–60 min" },
  { category: "Lashes" as const, description: "Soft lifts and classic extensions for refined definition.", startingPrice: 250, duration: "60–120 min" },
  { category: "Facials" as const, description: "Glow, hydration, and tailored care in a calm treatment setting.", startingPrice: 280, duration: "45–90 min" },
  { category: "Bridal" as const, description: "Consultations, trials, and composed wedding-day beauty plans.", startingPrice: 350, duration: "By consultation" },
].map((item) => ({ ...item, image: images[item.category] }));

export const illustrativeAppointments = [
  { id: "seed-1", customer: "Amira Nasser", service: "Signature Blow-Dry", specialist: "Lina Rahman", date: "Today", time: "10:00 AM", price: 180, status: "Confirmed" },
  { id: "seed-2", customer: "Leila Farouk", service: "Hydration Facial", specialist: "Noor Al-Mansoori", date: "Today", time: "11:30 AM", price: 420, status: "Completed" },
  { id: "seed-3", customer: "Mariam Saeed", service: "Gel Manicure", specialist: "Maya El-Khoury", date: "Today", time: "1:00 PM", price: 180, status: "Pending" },
  { id: "seed-4", customer: "Nadine Khoury", service: "Brow Lamination", specialist: "Sofia Haddad", date: "Today", time: "2:30 PM", price: 280, status: "Confirmed" },
  { id: "seed-5", customer: "Rania Malik", service: "Haircut and Finish", specialist: "Lina Rahman", date: "Tomorrow", time: "4:00 PM", price: 320, status: "Cancelled" },
] as const;

export const enquiries = [
  { name: "Hala Osman", source: "Instagram", service: "Bridal Beauty Package", message: "Looking for availability for a December wedding and a trial in October.", date: "Today, 9:18 AM", status: "New" },
  { name: "Dana Ali", source: "AI assistant", service: "Lash Lift", message: "Asked about preparation and requested a person to confirm suitability.", date: "Today, 10:42 AM", status: "Needs reply" },
  { name: "Yasmin Kareem", source: "WhatsApp", service: "Full Hair Colour", message: "Would like a colour consultation before booking.", date: "Yesterday", status: "In progress" },
  { name: "Salma Ibrahim", source: "Website", service: "Hydration Facial", message: "Checking whether the treatment is suitable for very dry skin.", date: "Yesterday", status: "Replied" },
];

export const revenueByCategory = [
  { category: "Hair", value: 9800, percent: 88 },
  { category: "Nails", value: 6700, percent: 61 },
  { category: "Brows & lashes", value: 5100, percent: 46 },
  { category: "Facials", value: 7600, percent: 69 },
  { category: "Bridal", value: 4200, percent: 38 },
];
