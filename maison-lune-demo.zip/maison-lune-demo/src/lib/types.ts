export type ServiceCategory = "Hair" | "Nails" | "Brows" | "Lashes" | "Facials" | "Bridal";

export type Service = {
  id: string;
  name: string;
  category: ServiceCategory;
  description: string;
  duration: number;
  price: number;
  priceLabel?: string;
  image: string;
  featured?: boolean;
};

export type Specialist = {
  id: string;
  name: string;
  role: string;
  specialty: string;
  bio: string;
  rating: number;
  availability: "Available today" | "Limited this week" | "Next available tomorrow";
  initials: string;
};

export type BookingCustomer = {
  fullName: string;
  phone: string;
  email: string;
  contactMethod: "WhatsApp" | "Phone" | "Email";
  notes?: string;
};

export type DemoBooking = {
  id: string;
  reference: string;
  createdAt: string;
  serviceId: string;
  serviceName: string;
  category: ServiceCategory;
  specialistId: string;
  specialistName: string;
  date: string;
  time: string;
  duration: number;
  price: number;
  customer: BookingCustomer;
  status: "Confirmed" | "Pending" | "Completed" | "Cancelled";
  source: "Website";
};
